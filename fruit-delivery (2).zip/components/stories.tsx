"use client"

import { useState } from "react"
import Image from "next/image"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

// Данные для историй
const stories = [
  {
    id: 1,
    title: "Сезонные фрукты",
    image: "https://images.unsplash.com/photo-1619566636858-adf3ef46400b?q=80&w=500&auto=format&fit=crop",
    content: "Свежие сезонные фрукты уже в продаже! Спешите попробовать!",
  },
  {
    id: 2,
    title: "Скидки на овощи",
    image: "https://images.unsplash.com/photo-1566385101042-1a0aa0c1268c?q=80&w=500&auto=format&fit=crop",
    content: "Скидки до 20% на все овощи до конца недели!",
  },
  {
    id: 3,
    title: "Новинка: сухофрукты",
    image: "https://images.unsplash.com/photo-1596591868231-05e882e38a8f?q=80&w=500&auto=format&fit=crop",
    content: "Попробуйте наши новые натуральные сухофрукты без добавок!",
  },
  {
    id: 4,
    title: "Бесплатная доставка",
    image: "https://images.unsplash.com/photo-1616401784845-180882ba9ba8?q=80&w=500&auto=format&fit=crop",
    content: "Бесплатная доставка при заказе от 2399 ₽!",
  },
]

export default function Stories() {
  const [openStory, setOpenStory] = useState<number | null>(null)
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0)

  const handleOpenStory = (id: number) => {
    setOpenStory(id)
    setCurrentStoryIndex(stories.findIndex((story) => story.id === id))
  }

  const handleCloseStory = () => {
    setOpenStory(null)
  }

  const handleNextStory = () => {
    if (currentStoryIndex < stories.length - 1) {
      setCurrentStoryIndex((prev) => prev + 1)
    } else {
      handleCloseStory()
    }
  }

  const handlePrevStory = () => {
    if (currentStoryIndex > 0) {
      setCurrentStoryIndex((prev) => prev - 1)
    }
  }

  const currentStory = stories[currentStoryIndex]

  return (
    <div className="py-6">
      <div className="flex overflow-x-auto gap-4 pb-2 no-scrollbar">
        {stories.map((story) => (
          <div key={story.id} className="flex-shrink-0 cursor-pointer" onClick={() => handleOpenStory(story.id)}>
            <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-primary p-1">
              <div className="w-full h-full rounded-full overflow-hidden relative">
                <Image src={story.image || "/placeholder.svg"} alt={story.title} fill className="object-cover" />
              </div>
            </div>
            <p className="text-xs text-center mt-1 truncate w-20">{story.title}</p>
          </div>
        ))}
      </div>

      <Dialog open={openStory !== null} onOpenChange={handleCloseStory}>
        <DialogContent className="p-0 max-w-md border-none bg-transparent shadow-none">
          {currentStory && (
            <div className="relative h-[70vh] w-full rounded-xl overflow-hidden">
              <Image
                src={currentStory.image || "/placeholder.svg"}
                alt={currentStory.title}
                fill
                className="object-cover"
              />

              <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center">
                <div className="flex gap-1 flex-1">
                  {stories.map((_, index) => (
                    <div
                      key={index}
                      className={`h-1 rounded-full flex-1 ${index === currentStoryIndex ? "bg-white" : "bg-white/40"}`}
                    />
                  ))}
                </div>
                <Button variant="ghost" size="icon" className="text-white ml-2" onClick={handleCloseStory}>
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent">
                <h3 className="text-xl font-bold text-white mb-2">{currentStory.title}</h3>
                <p className="text-white/90">{currentStory.content}</p>
              </div>

              <div className="absolute inset-0 flex">
                <div className="w-1/3 h-full" onClick={handlePrevStory} />
                <div className="w-1/3 h-full" onClick={handleCloseStory} />
                <div className="w-1/3 h-full" onClick={handleNextStory} />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

