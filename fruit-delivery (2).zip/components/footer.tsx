import Link from "next/link"
import Image from "next/image"
import { Phone, Mail, MapPin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="border-t bg-muted/30">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex flex-col items-center md:items-start gap-2 mb-4">
              <div className="relative h-12 w-12 overflow-hidden rounded-full">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Picsart_25-01-11_22-16-07-162.jpg-QY4FlwhBEe9MCzi7F5Lo2Ld8TFz9cm.jpeg"
                  alt="Olucha-fresh logo"
                  fill
                  className="object-contain"
                />
              </div>
              <h3 className="font-bold text-lg">Olucha-fresh</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Доставка свежих овощей, фруктов и сухофруктов по всему Челябинску
            </p>
            <div className="flex items-center text-sm text-muted-foreground">
              <Phone className="h-4 w-4 mr-2" />
              <span>+7 904 817-97-62</span>
            </div>
          </div>

          <div>
            <h3 className="font-bold mb-4">Навигация</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Главная
                </Link>
              </li>
              <li>
                <Link href="/catalog" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Каталог
                </Link>
              </li>
              <li>
                <Link href="/delivery" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Доставка
                </Link>
              </li>
              <li>
                <Link href="/contacts" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Контакты
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold mb-4">Категории</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/catalog?tab=vegetables"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  Овощи
                </Link>
              </li>
              <li>
                <Link
                  href="/catalog?tab=fruits"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  Фрукты
                </Link>
              </li>
              <li>
                <Link
                  href="/catalog?tab=dryFruits"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  Сухофрукты
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold mb-4">Контакты</h3>
            <div className="space-y-2">
              <div className="flex items-center text-sm text-muted-foreground">
                <Phone className="h-4 w-4 mr-2" />
                <span>+7 904 817-97-62</span>
              </div>
              <div className="flex items-center text-sm text-muted-foreground mt-1">
                <Phone className="h-4 w-4 mr-2" />
                <span>WhatsApp: +7 950 724-98-62</span>
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Mail className="h-4 w-4 mr-2" />
                <span>nematcon4@gmail.com</span>
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mr-2" />
                <span>г. Челябинск, ул. Артиллерийская, 116/1</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Olucha-fresh. Все права защищены.</p>
        </div>
      </div>
    </footer>
  )
}

