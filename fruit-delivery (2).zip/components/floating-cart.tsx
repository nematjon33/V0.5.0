"use client"

import { useState, useEffect } from "react"
import { ShoppingCart, Clock } from "lucide-react"
import { useCart } from "@/hooks/use-cart"
import Link from "next/link"
import { motion } from "framer-motion"

export default function FloatingCart() {
  const { items } = useCart()
  const [isVisible, setIsVisible] = useState(false)

  const totalItems = items.reduce((total, item) => total + item.quantity, 0)
  const totalPrice = items.reduce((total, item) => total + item.price * item.quantity, 0)

  // Показываем корзину только после скролла
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setIsVisible(true)
      } else {
        setIsVisible(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  if (items.length === 0 || !isVisible) return null

  return (
    <motion.div
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 100, opacity: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="fixed bottom-0 left-0 right-0 z-50"
    >
      <div className="container mx-auto px-4 pb-4">
        <Link href="/cart">
          <div className="bg-primary rounded-xl shadow-lg overflow-hidden">
            <div className="flex items-center justify-between p-4 text-primary-foreground">
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5" />
                <span className="text-sm font-medium">30-120 мин</span>
              </div>
              <div className="font-bold">Корзина</div>
              <div className="flex items-center gap-2">
                <ShoppingCart className="h-5 w-5" />
                <span className="font-bold">{totalPrice} ₽</span>
              </div>
            </div>
          </div>
        </Link>
      </div>
    </motion.div>
  )
}

