"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import {
  ShoppingCart,
  Menu,
  Phone,
  X,
  User,
  LogOut,
  History,
  Percent,
  Star,
  Home,
  ShoppingBag,
  Truck,
  Gift,
} from "lucide-react"
import { useCart } from "@/hooks/use-cart"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { usePathname } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { items } = useCart()
  const pathname = usePathname()
  const { user, isAuthenticated, logout } = useAuth()

  const totalItems = items.reduce((total, item) => total + item.quantity, 0)

  const navigation = [
    { name: "Главная", href: "/", icon: <Home className="h-4 w-4 mr-2" /> },
    { name: "Каталог", href: "/catalog", icon: <ShoppingBag className="h-4 w-4 mr-2" /> },
    { name: "Доставка", href: "/delivery", icon: <Truck className="h-4 w-4 mr-2" /> },
    { name: "Бонусы", href: "/bonus", icon: <Gift className="h-4 w-4 mr-2" /> },
    { name: "Отзывы", href: "/reviews", icon: <Star className="h-4 w-4 mr-2" /> },
    { name: "Контакты", href: "/contacts", icon: <Phone className="h-4 w-4 mr-2" /> },
  ]

  // Закрываем меню при переходе на другую страницу
  useEffect(() => {
    setIsMenuOpen(false)
  }, [pathname])

  return (
    <header className="border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Левая часть шапки - мобильное меню */}
          <div className="md:hidden">
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Открыть меню</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="bg-white/95 backdrop-blur-sm">
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between py-4">
                    <Link href="/" className="flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
                      <div className="relative h-10 w-10 overflow-hidden rounded-full">
                        <Image
                          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Picsart_25-01-11_22-16-07-162.jpg-QY4FlwhBEe9MCzi7F5Lo2Ld8TFz9cm.jpeg"
                          alt="Olucha-fresh logo"
                          fill
                          className="object-contain"
                        />
                      </div>
                      <span className="font-bold text-lg">Olucha-fresh</span>
                    </Link>
                    <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(false)}>
                      <X className="h-5 w-5" />
                    </Button>
                  </div>
                  <nav className="flex flex-col space-y-4 mt-8">
                    {navigation.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className={`text-base font-medium py-2 transition-colors flex items-center ${
                          pathname === item.href ? "text-primary" : "hover:text-primary"
                        }`}
                        onClick={() => setIsMenuOpen(false)}
                      >
                        {item.icon}
                        {item.name}
                      </Link>
                    ))}

                    {isAuthenticated ? (
                      <>
                        <Link
                          href="/orders"
                          className="text-base font-medium py-2 transition-colors hover:text-primary flex items-center"
                          onClick={() => setIsMenuOpen(false)}
                        >
                          <History className="h-4 w-4 mr-2" />
                          История заказов
                        </Link>
                        <Button variant="outline" onClick={logout} className="justify-start">
                          <LogOut className="mr-2 h-4 w-4" />
                          Выйти
                        </Button>
                      </>
                    ) : (
                      <Link
                        href="/auth/login"
                        className="text-base font-medium py-2 transition-colors hover:text-primary"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        Войти
                      </Link>
                    )}
                  </nav>
                  <div className="mt-auto py-4">
                    <div className="flex items-center mb-4">
                      <Phone className="h-4 w-4 mr-2 text-primary" />
                      <span className="text-sm font-medium">+7 904 817-97-62</span>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Центральная часть шапки - логотип и название */}
          <div className="flex-1 flex justify-center items-center">
            <Link href="/" className="flex flex-col items-center">
              <div className="relative h-12 w-12 overflow-hidden rounded-full border-2 border-primary/20">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Picsart_25-01-11_22-16-07-162.jpg-QY4FlwhBEe9MCzi7F5Lo2Ld8TFz9cm.jpeg"
                  alt="Olucha-fresh logo"
                  fill
                  className="object-contain"
                  priority
                />
              </div>
              <span className="font-bold text-xl mt-1 animate-text-gradient bg-gradient-to-r from-primary via-green-500 to-primary bg-[length:200%_auto] bg-clip-text text-transparent">
                Olucha-fresh
              </span>
            </Link>
          </div>

          {/* Правая часть шапки - навигация и корзина */}
          <div className="flex items-center">
            <div className="hidden md:flex items-center space-x-8 mr-6">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`text-sm font-medium transition-colors flex items-center ${
                    pathname === item.href ? "text-primary" : "hover:text-primary"
                  }`}
                >
                  {item.icon}
                  {item.name}
                </Link>
              ))}
            </div>

            <div className="hidden md:flex items-center mr-6">
              <Phone className="h-4 w-4 mr-2 text-primary" />
              <span className="text-sm font-medium">+7 904 817-97-62</span>
            </div>

            {/* Кнопка пользователя */}
            <div className="mr-4">
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon" className="rounded-full">
                      <User className="h-5 w-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Мой аккаунт</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <User className="mr-2 h-4 w-4" />
                      <span>{user?.name}</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Phone className="mr-2 h-4 w-4" />
                      <span>{user?.phone}</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/orders" className="flex items-center">
                        <History className="mr-2 h-4 w-4" />
                        <span>История заказов</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/bonus" className="flex items-center">
                        <Percent className="mr-2 h-4 w-4" />
                        <span>Бонусная программа</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/reviews" className="flex items-center">
                        <Star className="mr-2 h-4 w-4" />
                        <span>Отзывы</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={logout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Выйти</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button variant="outline" size="sm" asChild>
                  <Link href="/auth/login">
                    <User className="mr-2 h-4 w-4" />
                    Войти
                  </Link>
                </Button>
              )}
            </div>

            <Button asChild variant="outline" size="icon" className="relative hover:scale-105 transition-transform">
              <Link href="/cart">
                <ShoppingCart className="h-5 w-5" />
                {totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center animate-pulse">
                    {totalItems}
                  </span>
                )}
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}

