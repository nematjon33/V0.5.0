"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { X, Download } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export default function InstallPrompt() {
  const [showPrompt, setShowPrompt] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)

  useEffect(() => {
    // Проверяем, было ли уже показано предложение
    const hasShownPrompt = localStorage.getItem("installPromptShown")

    if (hasShownPrompt) return

    const handleBeforeInstallPrompt = (e: Event) => {
      // Предотвращаем показ стандартного диалога
      e.preventDefault()
      // Сохраняем событие для использования позже
      setDeferredPrompt(e)
      // Показываем наш собственный диалог
      setShowPrompt(true)
    }

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
    }
  }, [])

  const handleInstall = async () => {
    if (!deferredPrompt) return

    // Показываем диалог установки
    deferredPrompt.prompt()

    // Ждем ответа пользователя
    const { outcome } = await deferredPrompt.userChoice

    // Отмечаем, что предложение было показано
    localStorage.setItem("installPromptShown", "true")

    // Скрываем наш диалог
    setShowPrompt(false)
    setDeferredPrompt(null)
  }

  const handleDismiss = () => {
    // Отмечаем, что предложение было показано
    localStorage.setItem("installPromptShown", "true")
    setShowPrompt(false)
  }

  return (
    <AnimatePresence>
      {showPrompt && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-20 left-0 right-0 z-40 px-4"
        >
          <div className="bg-white rounded-lg shadow-lg p-4 mx-auto max-w-md border">
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-bold text-lg">Установить приложение</h3>
              <Button variant="ghost" size="icon" onClick={handleDismiss}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-muted-foreground mb-4">
              Установите наше приложение на главный экран для быстрого доступа и удобного использования.
            </p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={handleDismiss}>
                Не сейчас
              </Button>
              <Button onClick={handleInstall} className="hover:scale-105 transition-transform">
                <Download className="h-4 w-4 mr-2" />
                Установить
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

