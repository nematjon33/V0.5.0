"use client"

import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, Package, Truck, Search, XCircle } from "lucide-react"
import { formatDate } from "@/lib/utils"

interface OrderStatusProps {
  status: string
  statusHistory?: { status: string; timestamp: string }[]
  compact?: boolean
}

export default function OrderStatus({ status, statusHistory = [], compact = false }: OrderStatusProps) {
  const getStatusInfo = (statusCode: string) => {
    switch (statusCode) {
      case "created":
        return {
          label: "Заказ создан",
          color: "bg-blue-100 text-blue-800",
          icon: <Clock className="h-4 w-4 mr-1" />,
        }
      case "processing":
        return {
          label: "Заказ обрабатывается",
          color: "bg-purple-100 text-purple-800",
          icon: <Clock className="h-4 w-4 mr-1" />,
        }
      case "packaging":
        return {
          label: "Заказ собирается",
          color: "bg-indigo-100 text-indigo-800",
          icon: <Package className="h-4 w-4 mr-1" />,
        }
      case "finding_courier":
        return {
          label: "Поиск курьера",
          color: "bg-yellow-100 text-yellow-800",
          icon: <Search className="h-4 w-4 mr-1" />,
        }
      case "in_delivery":
        return {
          label: "В пути",
          color: "bg-orange-100 text-orange-800",
          icon: <Truck className="h-4 w-4 mr-1" />,
        }
      case "delivered":
        return {
          label: "Доставлен",
          color: "bg-green-100 text-green-800",
          icon: <CheckCircle className="h-4 w-4 mr-1" />,
        }
      case "cancelled":
        return {
          label: "Отменен",
          color: "bg-red-100 text-red-800",
          icon: <XCircle className="h-4 w-4 mr-1" />,
        }
      default:
        return {
          label: "Неизвестный статус",
          color: "bg-gray-100 text-gray-800",
          icon: <Clock className="h-4 w-4 mr-1" />,
        }
    }
  }

  const currentStatusInfo = getStatusInfo(status)

  if (compact) {
    return (
      <Badge variant="outline" className={currentStatusInfo.color}>
        <div className="flex items-center">
          {currentStatusInfo.icon}
          {currentStatusInfo.label}
        </div>
      </Badge>
    )
  }

  const steps = [
    { id: "created", label: "Заказ создан", icon: <Clock className="h-5 w-5" /> },
    { id: "processing", label: "Обработка", icon: <Clock className="h-5 w-5" /> },
    { id: "packaging", label: "Сборка", icon: <Package className="h-5 w-5" /> },
    { id: "finding_courier", label: "Поиск курьера", icon: <Search className="h-5 w-5" /> },
    { id: "in_delivery", label: "В пути", icon: <Truck className="h-5 w-5" /> },
    { id: "delivered", label: "Доставлен", icon: <CheckCircle className="h-5 w-5" /> },
  ]

  // Определяем текущий шаг
  const currentStepIndex = steps.findIndex((step) => step.id === status)
  const isCancelled = status === "cancelled"

  return (
    <div className="w-full">
      {isCancelled ? (
        <div className="flex items-center justify-center p-4 bg-red-50 rounded-lg">
          <XCircle className="h-6 w-6 text-red-500 mr-2" />
          <span className="font-medium text-red-700">Заказ отменен</span>
        </div>
      ) : (
        <>
          <div className="flex justify-between mb-4">
            {steps.map((step, index) => {
              const isActive = index <= currentStepIndex
              const isCurrentStep = index === currentStepIndex

              return (
                <div key={step.id} className="flex flex-col items-center">
                  <div
                    className={`
                    w-10 h-10 rounded-full flex items-center justify-center
                    ${isActive ? "bg-primary text-white" : "bg-gray-200 text-gray-500"}
                    ${isCurrentStep ? "ring-4 ring-primary/20" : ""}
                  `}
                  >
                    {step.icon}
                  </div>
                  <span
                    className={`text-xs mt-1 text-center ${isActive ? "text-primary font-medium" : "text-gray-500"}`}
                  >
                    {step.label}
                  </span>
                </div>
              )
            })}
          </div>

          <div className="relative h-2 bg-gray-200 rounded-full mb-6">
            <div
              className="absolute top-0 left-0 h-2 bg-primary rounded-full"
              style={{ width: `${Math.min(100, (currentStepIndex / (steps.length - 1)) * 100)}%` }}
            />
          </div>
        </>
      )}

      {statusHistory.length > 0 && (
        <div className="mt-4 border-t pt-4">
          <h4 className="font-medium mb-2">История статусов:</h4>
          <div className="space-y-2">
            {statusHistory.map((item, index) => {
              const { label, icon } = getStatusInfo(item.status)
              return (
                <div key={index} className="flex items-center text-sm">
                  <div className="mr-2">{icon}</div>
                  <span className="font-medium">{label}</span>
                  <span className="mx-2">-</span>
                  <span className="text-muted-foreground">{formatDate(new Date(item.timestamp))}</span>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

