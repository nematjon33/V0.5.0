"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import type { Product } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, Plus, Edit, Trash2, RefreshCw, Ban, CheckCircle } from "lucide-react"
import { Input } from "@/components/ui/input"
import Image from "next/image"
import ProductForm from "./product-form"
import { v4 as uuidv4 } from "uuid"
import { useProducts } from "@/hooks/use-products"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

export default function ProductsPanel() {
  const { products, addProduct, updateProduct, deleteProduct, loading, refreshProducts } = useProducts()
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [uploadedImages, setUploadedImages] = useState<string[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  // Фильтрация товаров
  useEffect(() => {
    if (!products.length) return

    let filtered = [...products]

    // Фильтрация по категории
    if (categoryFilter !== "all") {
      filtered = filtered.filter((product) => product.category === categoryFilter)
    }

    // Фильтрация по поисковому запросу
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (product) => product.name.toLowerCase().includes(term) || product.description.toLowerCase().includes(term),
      )
    }

    setFilteredProducts(filtered)
  }, [products, categoryFilter, searchTerm])

  const handleSaveProduct = async (productData: Partial<Product>) => {
    try {
      if (productData.id) {
        // Обновление существующего товара
        const updatedProduct = {
          ...selectedProduct!,
          ...productData,
        } as Product

        updateProduct(updatedProduct)

        toast({
          title: "Товар обновлен",
          description: `Товар "${updatedProduct.name}" успешно обновлен`,
        })
      } else {
        // Добавление нового товара
        const newProduct = {
          id: uuidv4(),
          name: productData.name || "Новый товар",
          description: productData.description || "",
          price: productData.price || 0,
          category: productData.category || "other",
          images: productData.images,
          stock: productData.stock,
          inStock: productData.inStock,
        } as Product

        addProduct(newProduct)

        toast({
          title: "Товар добавлен",
          description: `Товар "${newProduct.name}" успешно добавлен`,
        })
      }

      setIsAddDialogOpen(false)
      setIsEditDialogOpen(false)
      setSelectedProduct(null)
      setUploadedImages([])
    } catch (error) {
      console.error("Ошибка при сохранении товара:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить товар",
        variant: "destructive",
      })
    }
  }

  const handleDeleteProduct = async () => {
    if (!selectedProduct) return

    try {
      deleteProduct(selectedProduct.id)

      toast({
        title: "Товар удален",
        description: `Товар "${selectedProduct.name}" успешно удален`,
      })

      setIsDeleteDialogOpen(false)
      setSelectedProduct(null)
    } catch (error) {
      console.error("Ошибка при удалении товара:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось удалить товар",
        variant: "destructive",
      })
    }
  }

  // Обработка загрузки изображения
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files || files.length === 0) return

    // Ограничение на количество изображений
    const remainingSlots = 5 - (selectedProduct?.images?.length || 0) - uploadedImages.length
    if (remainingSlots <= 0) {
      toast({
        title: "Ошибка",
        description: "Можно загрузить максимум 5 изображений",
        variant: "destructive",
      })
      return
    }

    const filesToProcess = Array.from(files).slice(0, remainingSlots)

    const newImages: string[] = []
    let processed = 0

    filesToProcess.forEach((file) => {
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Ошибка",
          description: "Пожалуйста, выберите изображение",
          variant: "destructive",
        })
        return
      }

      const reader = new FileReader()
      reader.onload = (e) => {
        if (e.target?.result) {
          newImages.push(e.target.result.toString())
          processed++

          if (processed === filesToProcess.length) {
            setUploadedImages((prev) => [...prev, ...newImages])

            toast({
              title: "Изображения загружены",
              description: `Загружено ${newImages.length} изображений`,
            })
          }
        }
      }
      reader.readAsDataURL(file)
    })
  }

  const toggleProductAvailability = (product: Product) => {
    const updatedProduct = {
      ...product,
      inStock: !product.inStock,
    }

    updateProduct(updatedProduct)

    toast({
      title: updatedProduct.inStock ? "Товар доступен" : "Товар недоступен",
      description: `Товар "${product.name}" ${updatedProduct.inStock ? "теперь доступен" : "больше не доступен"} для заказа`,
    })
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Поиск товаров..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex gap-2">
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Категория" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все категории</SelectItem>
                <SelectItem value="vegetables">🥦 Овощи</SelectItem>
                <SelectItem value="fruits">🍎 Фрукты</SelectItem>
                <SelectItem value="dryFruits">🥜 Сухофрукты</SelectItem>
                <SelectItem value="drinks">🥤 Напитки</SelectItem>
                <SelectItem value="other">Другое</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              onClick={() => refreshProducts()}
              disabled={loading}
              className="hover:scale-105 transition-transform"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
              Обновить
            </Button>

            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="animate-pulse hover:animate-none">
                  <Plus className="h-4 w-4 mr-2" />
                  Добавить товар
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-3xl">
                <DialogHeader>
                  <DialogTitle>Добавить новый товар</DialogTitle>
                </DialogHeader>
                <ProductForm
                  uploadedImages={uploadedImages}
                  onSave={handleSaveProduct}
                  onCancel={() => {
                    setIsAddDialogOpen(false)
                    setUploadedImages([])
                  }}
                  onImageUpload={() => fileInputRef.current?.click()}
                />
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept="image/*"
                  onChange={handleImageUpload}
                  multiple
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>
        <CardDescription>
          {filteredProducts.length ? `Найдено ${filteredProducts.length} товаров` : "Товары не найдены"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px] pr-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredProducts.map((product) => (
              <Card key={product.id} className="overflow-hidden">
                <div className="relative h-40">
                  <Image
                    src={product.images?.[0] || product.image || "/placeholder.svg?height=200&width=300"}
                    alt={product.name}
                    fill
                    className="object-cover"
                  />
                  {product.category === "fruits" && (
                    <Badge className="absolute top-2 right-2 bg-orange-500 hover:bg-orange-600">🍎 Фрукты</Badge>
                  )}
                  {product.category === "vegetables" && (
                    <Badge className="absolute top-2 right-2 bg-green-500 hover:bg-green-600">🥦 Овощи</Badge>
                  )}
                  {product.category === "dryFruits" && (
                    <Badge className="absolute top-2 right-2 bg-amber-500 hover:bg-amber-600">🥜 Сухофрукты</Badge>
                  )}
                  {product.category === "drinks" && (
                    <Badge className="absolute top-2 right-2 bg-blue-500 hover:bg-blue-600">🥤 Напитки</Badge>
                  )}
                  {product.inStock === false && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <Badge className="bg-red-500 text-white px-3 py-1 text-sm">Нет в наличии</Badge>
                    </div>
                  )}
                </div>
                <CardContent className="p-4">
                  <h3 className="font-medium text-lg truncate">{product.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{product.description}</p>
                  <div className="mt-2 font-bold text-primary">{product.price} ₽/кг</div>

                  {product.stock !== undefined && (
                    <div className="mt-1 text-sm">
                      <span className="text-muted-foreground">В наличии:</span> {product.stock} кг
                    </div>
                  )}

                  <div className="flex justify-between gap-2 mt-4">
                    <Button
                      variant={product.inStock === false ? "outline" : "destructive"}
                      size="sm"
                      className="flex-1 hover:scale-105 transition-transform"
                      onClick={() => toggleProductAvailability(product)}
                    >
                      {product.inStock === false ? (
                        <>
                          <CheckCircle className="h-4 w-4 mr-2" />В продажу
                        </>
                      ) : (
                        <>
                          <Ban className="h-4 w-4 mr-2" />
                          Снять
                        </>
                      )}
                    </Button>

                    <Dialog
                      open={isEditDialogOpen && selectedProduct?.id === product.id}
                      onOpenChange={(open) => {
                        setIsEditDialogOpen(open)
                        if (open) {
                          setSelectedProduct(product)
                          setUploadedImages([])
                        }
                      }}
                    >
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="flex-1 hover:scale-105 transition-transform">
                          <Edit className="h-4 w-4 mr-2" />
                          Изменить
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-3xl">
                        <DialogHeader>
                          <DialogTitle>Редактировать товар</DialogTitle>
                        </DialogHeader>
                        {selectedProduct && (
                          <ProductForm
                            product={selectedProduct}
                            uploadedImages={uploadedImages}
                            onSave={handleSaveProduct}
                            onCancel={() => {
                              setIsEditDialogOpen(false)
                              setUploadedImages([])
                            }}
                            onImageUpload={() => fileInputRef.current?.click()}
                          />
                        )}
                      </DialogContent>
                    </Dialog>

                    <Dialog
                      open={isDeleteDialogOpen && selectedProduct?.id === product.id}
                      onOpenChange={(open) => {
                        setIsDeleteDialogOpen(open)
                        if (open) setSelectedProduct(product)
                      }}
                    >
                      <DialogTrigger asChild>
                        <Button variant="destructive" size="sm" className="hover:scale-105 transition-transform">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Удалить товар</DialogTitle>
                        </DialogHeader>
                        <p className="py-4">
                          Вы уверены, что хотите удалить товар "{selectedProduct?.name}"? Это действие нельзя отменить.
                        </p>
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                            Отмена
                          </Button>
                          <Button
                            variant="destructive"
                            onClick={handleDeleteProduct}
                            className="hover:scale-105 transition-transform"
                          >
                            Удалить
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

