"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Product } from "@/lib/types"
import Image from "next/image"
import { X, Plus } from "lucide-react"
import { Switch } from "@/components/ui/switch"

interface ProductFormProps {
  product?: Product
  uploadedImages?: string[] | null
  onSave: (product: Partial<Product>) => void
  onCancel: () => void
  onImageUpload: () => void
}

export default function ProductForm({ product, uploadedImages, onSave, onCancel, onImageUpload }: ProductFormProps) {
  const [name, setName] = useState(product?.name || "")
  const [description, setDescription] = useState(product?.description || "")
  const [price, setPrice] = useState(product?.price?.toString() || "")
  const [category, setCategory] = useState<string>(product?.category || "vegetables")
  const [images, setImages] = useState<string[]>(product?.images || [])
  const [stock, setStock] = useState(product?.stock?.toString() || "")
  const [inStock, setInStock] = useState(product?.inStock !== false)
  const { toast } = useToast()

  // Обновляем изображения, если загружены новые
  useEffect(() => {
    if (uploadedImages && uploadedImages.length > 0) {
      setImages((prev) => {
        // Ограничиваем количество изображений до 5
        const newImages = [...prev, ...uploadedImages].slice(0, 5)
        return newImages
      })
    }
  }, [uploadedImages])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!name || !price) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, заполните все обязательные поля",
        variant: "destructive",
      })
      return
    }

    const priceValue = Number.parseFloat(price)
    if (isNaN(priceValue) || priceValue <= 0) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, введите корректную цену",
        variant: "destructive",
      })
      return
    }

    const stockValue = stock ? Number.parseInt(stock) : undefined
    if (stock && (isNaN(stockValue!) || stockValue! < 0)) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, введите корректное количество товара",
        variant: "destructive",
      })
      return
    }

    onSave({
      id: product?.id,
      name,
      description,
      price: priceValue,
      category: category as "vegetables" | "fruits" | "dryFruits" | "drinks" | "other",
      images: images.length > 0 ? images : undefined,
      stock: stockValue,
      inStock,
    })
  }

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-4">
          <div>
            <Label htmlFor="name">Название товара*</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>

          <div>
            <Label htmlFor="price">Цена за кг*</Label>
            <Input
              id="price"
              type="number"
              min="0.01"
              step="0.01"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="category">Категория</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Выберите категорию" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="vegetables">🥦 Овощи</SelectItem>
                <SelectItem value="fruits">🍎 Фрукты</SelectItem>
                <SelectItem value="dryFruits">🥜 Сухофрукты</SelectItem>
                <SelectItem value="drinks">🥤 Напитки</SelectItem>
                <SelectItem value="other">Другое</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="stock">Количество в наличии (кг)</Label>
            <Input id="stock" type="number" min="0" step="1" value={stock} onChange={(e) => setStock(e.target.value)} />
          </div>

          <div className="flex items-center space-x-2">
            <Switch id="inStock" checked={inStock} onCheckedChange={setInStock} />
            <Label htmlFor="inStock">В наличии</Label>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <Label htmlFor="description">Описание</Label>
            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={4} />
          </div>

          <div>
            <Label>Изображения товара (до 5 шт.)</Label>
            <div className="grid grid-cols-3 gap-2 mt-2">
              {images.map((image, index) => (
                <div key={index} className="relative h-24 rounded-md overflow-hidden border">
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={name || "Изображение товара"}
                    fill
                    className="object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute top-1 right-1 bg-black/50 rounded-full p-1"
                  >
                    <X className="h-4 w-4 text-white" />
                  </button>
                </div>
              ))}
              {images.length < 5 && (
                <button
                  type="button"
                  onClick={onImageUpload}
                  className="h-24 border-2 border-dashed rounded-md flex flex-col items-center justify-center hover:bg-muted/50 transition-colors"
                >
                  <Plus className="h-6 w-6 text-muted-foreground mb-1" />
                  <span className="text-xs text-muted-foreground">Добавить</span>
                </button>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Нажмите на кнопку, чтобы добавить изображение</p>
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Отмена
        </Button>
        <Button type="submit" className="hover:scale-105 transition-transform">
          {product ? "Сохранить изменения" : "Добавить товар"}
        </Button>
      </div>
    </form>
  )
}

