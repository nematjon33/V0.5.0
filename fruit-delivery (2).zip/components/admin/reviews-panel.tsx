"use client"

import { useState, useEffect } from "react"
import { useReviews } from "@/hooks/use-reviews"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, User, Calendar, CheckCircle, XCircle, RefreshCw } from "lucide-react"
import { formatDate } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"

export default function ReviewsPanel() {
  const { getPendingReviews, getApprovedReviews, approveReview, rejectReview } = useReviews()
  const [pendingReviews, setPendingReviews] = useState<any[]>([])
  const [approvedReviews, setApprovedReviews] = useState<any[]>([])
  const [activeTab, setActiveTab] = useState("pending")

  useEffect(() => {
    refreshReviews()
  }, [])

  const refreshReviews = () => {
    setPendingReviews(getPendingReviews())
    setApprovedReviews(getApprovedReviews())
  }

  const handleApproveReview = (id: string) => {
    approveReview(id)
    refreshReviews()
  }

  const handleRejectReview = (id: string) => {
    rejectReview(id)
    refreshReviews()
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div>
            <CardTitle>Управление отзывами</CardTitle>
            <CardDescription>Модерация и просмотр отзывов клиентов</CardDescription>
          </div>

          <Button variant="outline" onClick={refreshReviews} className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4" />
            Обновить
          </Button>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="pending">
              На модерации
              {pendingReviews.length > 0 && <Badge className="ml-2 bg-primary">{pendingReviews.length}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="approved">Опубликованные</TabsTrigger>
          </TabsList>

          <TabsContent value="pending">
            <ScrollArea className="h-[500px] pr-4">
              {pendingReviews.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Нет отзывов на модерации</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingReviews.map((review) => (
                    <Card key={review.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg flex items-center">
                            <User className="h-5 w-5 mr-2 text-muted-foreground" />
                            {review.userName}
                          </CardTitle>
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-5 w-5 ${
                                  star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-200"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground flex items-center mt-1">
                          <Calendar className="h-4 w-4 mr-1" />
                          {formatDate(new Date(review.date))}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="mb-4">{review.text}</p>

                        {review.images && review.images.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-4 mb-4">
                            {review.images.map((image: string, index: number) => (
                              <div key={index} className="relative h-20 w-20 rounded overflow-hidden">
                                <Image
                                  src={image || "/placeholder.svg"}
                                  alt={`Фото ${index + 1}`}
                                  fill
                                  className="object-cover"
                                />
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="flex justify-end gap-2 mt-4 pt-4 border-t">
                          <Button
                            variant="outline"
                            onClick={() => handleRejectReview(review.id)}
                            className="flex items-center gap-2 text-red-600 hover:text-red-700"
                          >
                            <XCircle className="h-4 w-4" />
                            Отклонить
                          </Button>
                          <Button onClick={() => handleApproveReview(review.id)} className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            Опубликовать
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          </TabsContent>

          <TabsContent value="approved">
            <ScrollArea className="h-[500px] pr-4">
              {approvedReviews.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Нет опубликованных отзывов</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {approvedReviews.map((review) => (
                    <Card key={review.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg flex items-center">
                            <User className="h-5 w-5 mr-2 text-muted-foreground" />
                            {review.userName}
                          </CardTitle>
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-5 w-5 ${
                                  star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-200"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground flex items-center mt-1">
                          <Calendar className="h-4 w-4 mr-1" />
                          {formatDate(new Date(review.date))}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="mb-4">{review.text}</p>

                        {review.images && review.images.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-4">
                            {review.images.map((image: string, index: number) => (
                              <div key={index} className="relative h-20 w-20 rounded overflow-hidden">
                                <Image
                                  src={image || "/placeholder.svg"}
                                  alt={`Фото ${index + 1}`}
                                  fill
                                  className="object-cover"
                                />
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

