"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import LoginForm from "./login-form"
import AdminPanel from "./admin-panel"

export default function AdminButton() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  return (
    <>
      <Button
        variant="link"
        className="text-xs text-muted-foreground hover:text-muted-foreground/80"
        onClick={() => setIsDialogOpen(true)}
      >
        Панель управления
      </Button>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{isLoggedIn ? "Панель управления" : "Вход в панель управления"}</DialogTitle>
          </DialogHeader>

          {isLoggedIn ? (
            <AdminPanel onLogout={() => setIsLoggedIn(false)} />
          ) : (
            <LoginForm onLogin={() => setIsLoggedIn(true)} />
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}

