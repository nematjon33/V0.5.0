"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Trash2, Plus, RefreshCw, Truck } from "lucide-react"
import {
  getDeliveryPricing,
  saveDeliveryPricing,
  getDeliveryCoefficient,
  saveDeliveryCoefficient,
  DEFAULT_DELIVERY_PRICING,
  DEFAULT_DELIVERY_COEFFICIENT,
} from "@/lib/local-storage"
import type { DeliveryPricing } from "@/lib/types"

export default function DeliveryPanel() {
  const [deliveryPricing, setDeliveryPricing] = useState<DeliveryPricing[]>([])
  const [deliveryCoefficient, setDeliveryCoefficient] = useState(1.0)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  // Загрузка настроек доставки при инициализации
  useEffect(() => {
    loadDeliverySettings()
  }, [])

  // Функция для загрузки настроек доставки
  const loadDeliverySettings = () => {
    try {
      setIsLoading(true)

      // Загружаем настройки доставки из локального хранилища
      const pricing = getDeliveryPricing()
      const coefficient = getDeliveryCoefficient()

      setDeliveryPricing(pricing)
      setDeliveryCoefficient(coefficient)
    } catch (error) {
      console.error("Ошибка при загрузке настроек доставки:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить настройки доставки",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Функция для сохранения настроек доставки
  const saveDeliverySettings = () => {
    try {
      setIsLoading(true)

      // Проверяем корректность настроек
      for (let i = 0; i < deliveryPricing.length; i++) {
        const rule = deliveryPricing[i]

        // Проверяем, что минимальная сумма заказа не отрицательная
        if (rule.minOrderAmount < 0) {
          throw new Error("Минимальная сумма заказа не может быть отрицательной")
        }

        // Проверяем, что максимальная сумма заказа больше минимальной
        if (rule.maxOrderAmount !== null && rule.maxOrderAmount <= rule.minOrderAmount) {
          throw new Error("Максимальная сумма заказа должна быть больше минимальной")
        }

        // Проверяем, что стоимость доставки не отрицательная
        if (rule.price < 0) {
          throw new Error("Стоимость доставки не может быть отрицательной")
        }

        // Проверяем, что диапазоны не пересекаются
        if (i > 0) {
          const prevRule = deliveryPricing[i - 1]
          if (prevRule.maxOrderAmount !== null && rule.minOrderAmount < prevRule.maxOrderAmount) {
            throw new Error("Диапазоны сумм заказа не должны пересекаться")
          }
        }
      }

      // Проверяем, что коэффициент доставки положительный
      if (deliveryCoefficient <= 0) {
        throw new Error("Коэффициент доставки должен быть положительным числом")
      }

      // Сохраняем настройки доставки в локальное хранилище
      saveDeliveryPricing(deliveryPricing)
      saveDeliveryCoefficient(deliveryCoefficient)

      toast({
        title: "Настройки сохранены",
        description: "Настройки доставки успешно сохранены",
      })
    } catch (error) {
      console.error("Ошибка при сохранении настроек доставки:", error)
      toast({
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось сохранить настройки доставки",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Функция для сброса настроек доставки к значениям по умолчанию
  const resetDeliverySettings = () => {
    setDeliveryPricing([...DEFAULT_DELIVERY_PRICING])
    setDeliveryCoefficient(DEFAULT_DELIVERY_COEFFICIENT)

    toast({
      title: "Настройки сброшены",
      description: "Настройки доставки сброшены к значениям по умолчанию",
    })
  }

  // Функция для добавления нового правила доставки
  const addPricingRule = () => {
    // Находим максимальную сумму заказа в последнем правиле
    const lastRule = deliveryPricing[deliveryPricing.length - 1]
    const minOrderAmount = lastRule.maxOrderAmount !== null ? lastRule.maxOrderAmount + 1 : 0

    const newRule: DeliveryPricing = {
      minOrderAmount,
      maxOrderAmount: minOrderAmount + 1000,
      price: 0,
    }

    setDeliveryPricing([...deliveryPricing, newRule])
  }

  // Функция для удаления правила доставки
  const removePricingRule = (index: number) => {
    const updatedPricing = [...deliveryPricing]
    updatedPricing.splice(index, 1)
    setDeliveryPricing(updatedPricing)
  }

  // Функция для обновления правила доставки
  const updatePricingRule = (index: number, field: keyof DeliveryPricing, value: any) => {
    const updatedPricing = [...deliveryPricing]
    updatedPricing[index] = {
      ...updatedPricing[index],
      [field]: value,
    }
    setDeliveryPricing(updatedPricing)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Настройки доставки</CardTitle>
            <CardDescription>Управление стоимостью доставки в зависимости от суммы заказа</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={resetDeliverySettings} className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4" />
              Сбросить
            </Button>
            <Button onClick={saveDeliverySettings} disabled={isLoading} className="flex items-center gap-2">
              <Truck className="h-4 w-4" />
              Сохранить
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium mb-4">Стоимость доставки в зависимости от суммы заказа</h3>
            <div className="space-y-4">
              {deliveryPricing.map((rule, index) => (
                <div key={index} className="flex items-end gap-4 border p-4 rounded-md">
                  <div className="flex-1">
                    <Label htmlFor={`min-${index}`}>От (₽)</Label>
                    <Input
                      id={`min-${index}`}
                      type="number"
                      value={rule.minOrderAmount}
                      onChange={(e) => updatePricingRule(index, "minOrderAmount", Number.parseInt(e.target.value))}
                      min="0"
                    />
                  </div>
                  <div className="flex-1">
                    <Label htmlFor={`max-${index}`}>До (₽)</Label>
                    <Input
                      id={`max-${index}`}
                      type="number"
                      value={rule.maxOrderAmount === null ? "" : rule.maxOrderAmount}
                      onChange={(e) => {
                        const value = e.target.value === "" ? null : Number.parseInt(e.target.value)
                        updatePricingRule(index, "maxOrderAmount", value)
                      }}
                      min={rule.minOrderAmount + 1}
                      placeholder="Без ограничения"
                    />
                  </div>
                  <div className="flex-1">
                    <Label htmlFor={`price-${index}`}>Стоимость доставки (₽)</Label>
                    <Input
                      id={`price-${index}`}
                      type="number"
                      value={rule.price}
                      onChange={(e) => updatePricingRule(index, "price", Number.parseInt(e.target.value))}
                      min="0"
                    />
                  </div>
                  <Button
                    variant="destructive"
                    size="icon"
                    onClick={() => removePricingRule(index)}
                    disabled={deliveryPricing.length <= 1}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button variant="outline" onClick={addPricingRule} className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Добавить правило
              </Button>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-medium mb-4">Коэффициент доставки</h3>
            <div className="flex items-end gap-4">
              <div className="flex-1">
                <Label htmlFor="coefficient">
                  Коэффициент (для периодов высокого спроса или неблагоприятных погодных условий)
                </Label>
                <Input
                  id="coefficient"
                  type="number"
                  value={deliveryCoefficient}
                  onChange={(e) => setDeliveryCoefficient(Number.parseFloat(e.target.value))}
                  min="0.1"
                  step="0.1"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Значение 1.0 означает стандартную стоимость доставки. Значение 1.5 означает увеличение стоимости
                  доставки на 50%.
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

