"use client"

import { useState, useEffect } from "react"
import { useBonus } from "@/hooks/use-bonus"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, RefreshCw, Percent, Calendar } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { formatDate } from "@/lib/utils"

export default function BonusPanel() {
  const { allBonusInfo, loading } = useBonus()
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredBonuses, setFilteredBonuses] = useState(allBonusInfo)

  // Фильтрация бонусов при изменении поискового запроса
  useEffect(() => {
    if (!searchTerm) {
      setFilteredBonuses(allBonusInfo)
      return
    }

    const term = searchTerm.toLowerCase()
    const filtered = allBonusInfo.filter(
      (bonus) => bonus.userName.toLowerCase().includes(term) || bonus.userPhone.toLowerCase().includes(term),
    )

    setFilteredBonuses(filtered)
  }, [searchTerm, allBonusInfo])

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Бонусная программа</CardTitle>
            <CardDescription>Управление скидками пользователей</CardDescription>
          </div>
          <Button variant="outline" size="sm" className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4" />
            Обновить
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Поиск по имени или телефону..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <ScrollArea className="h-[400px]">
          <div className="space-y-4">
            {filteredBonuses.length > 0 ? (
              filteredBonuses.map((bonus) => (
                <Card key={bonus.userId} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">{bonus.userName}</h3>
                        <p className="text-sm text-muted-foreground">{bonus.userPhone}</p>
                      </div>
                      <Badge className="bg-primary">
                        <Percent className="h-3 w-3 mr-1" />
                        {bonus.discountPercent}%
                      </Badge>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Последний заказ:</span>
                        <p>{bonus.lastOrderAmount} ₽</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Дата заказа:</span>
                        <p>{formatDate(new Date(bonus.lastOrderDate))}</p>
                      </div>
                      <div className="col-span-2">
                        <span className="text-muted-foreground flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          Сброс скидки:
                        </span>
                        <p>{formatDate(new Date(bonus.nextResetDate))}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Бонусы не найдены</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

