"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LogOut } from "lucide-react"
import ProductsPanel from "./products-panel"
import BonusPanel from "./bonus-panel"
import OrdersPanel from "./orders-panel"
import ReviewsPanel from "./reviews-panel"
import DeliveryPanel from "./delivery-panel"

interface AdminPanelProps {
  onLogout?: () => void
}

export default function AdminPanel({ onLogout }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState("products")

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Панель управления</h2>
        {onLogout && (
          <Button variant="outline" onClick={onLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Выйти
          </Button>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-5 mb-6">
          <TabsTrigger value="products">Товары</TabsTrigger>
          <TabsTrigger value="orders">Заказы</TabsTrigger>
          <TabsTrigger value="reviews">Отзывы</TabsTrigger>
          <TabsTrigger value="bonus">Бонусы</TabsTrigger>
          <TabsTrigger value="delivery">Доставка</TabsTrigger>
        </TabsList>

        <TabsContent value="products">
          <ProductsPanel />
        </TabsContent>

        <TabsContent value="orders">
          <OrdersPanel />
        </TabsContent>

        <TabsContent value="reviews">
          <ReviewsPanel />
        </TabsContent>

        <TabsContent value="bonus">
          <BonusPanel />
        </TabsContent>

        <TabsContent value="delivery">
          <DeliveryPanel />
        </TabsContent>
      </Tabs>
    </div>
  )
}

