"use client"

import { useState, useEffect } from "react"
import { useOrders } from "@/hooks/use-orders"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger } from "@/components/ui/select"
import { Search, RefreshCw, Package, Truck, CheckCircle, XCircle, Clock, Filter } from "lucide-react"
import { formatDate } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import OrderStatus from "@/components/order-status"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export default function OrdersPanel() {
  const { getAllOrders, updateOrderStatus } = useOrders()
  const [orders, setOrders] = useState<any[]>([])
  const [filteredOrders, setFilteredOrders] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedOrder, setSelectedOrder] = useState<any>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  useEffect(() => {
    const allOrders = getAllOrders()
    setOrders(allOrders)
    setFilteredOrders(allOrders)
  }, [getAllOrders])

  useEffect(() => {
    let result = orders

    // Фильтрация по статусу
    if (statusFilter !== "all") {
      result = result.filter((order) => order.status === statusFilter)
    }

    // Фильтрация по поиску
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      result = result.filter(
        (order) =>
          order.id.toLowerCase().includes(term) ||
          order.name.toLowerCase().includes(term) ||
          order.phone.toLowerCase().includes(term) ||
          order.address.toLowerCase().includes(term),
      )
    }

    setFilteredOrders(result)
  }, [orders, searchTerm, statusFilter])

  const handleStatusChange = (orderId: string, newStatus: string) => {
    updateOrderStatus(orderId, newStatus as any)
    setOrders(getAllOrders())
    setIsDialogOpen(false)
  }

  const refreshOrders = () => {
    setOrders(getAllOrders())
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div>
            <CardTitle>Управление заказами</CardTitle>
            <CardDescription>Просмотр и изменение статусов заказов</CardDescription>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={refreshOrders} className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4" />
              Обновить
            </Button>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mt-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Поиск по номеру, имени или адресу..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="w-full md:w-64">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <div className="flex items-center">
                  <Filter className="h-4 w-4 mr-2" />
                  <span>Статус</span>
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все заказы</SelectItem>
                <SelectItem value="created">Созданные</SelectItem>
                <SelectItem value="processing">В обработке</SelectItem>
                <SelectItem value="packaging">Сборка</SelectItem>
                <SelectItem value="finding_courier">Поиск курьера</SelectItem>
                <SelectItem value="in_delivery">В пути</SelectItem>
                <SelectItem value="delivered">Доставленные</SelectItem>
                <SelectItem value="cancelled">Отмененные</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <ScrollArea className="h-[600px] pr-4">
          {filteredOrders.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Заказы не найдены</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredOrders.map((order) => (
                <Card key={order.id} className="overflow-hidden">
                  <CardHeader className="bg-muted/30 pb-4">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                      <div>
                        <CardTitle className="text-lg">Заказ #{order.id.split("-")[1]}</CardTitle>
                        <CardDescription>{formatDate(new Date(order.date))}</CardDescription>
                      </div>
                      <div className="flex flex-col md:flex-row items-start md:items-center gap-2 mt-2 md:mt-0">
                        <OrderStatus status={order.status} compact />
                        <div className="font-bold">{order.finalPrice} ₽</div>

                        <Dialog
                          open={isDialogOpen && selectedOrder?.id === order.id}
                          onOpenChange={(open) => {
                            setIsDialogOpen(open)
                            if (open) setSelectedOrder(order)
                          }}
                        >
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" onClick={() => setSelectedOrder(order)}>
                              Изменить статус
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Изменить статус заказа #{order.id.split("-")[1]}</DialogTitle>
                            </DialogHeader>
                            <div className="grid gap-4 py-4">
                              <div className="grid grid-cols-2 gap-4">
                                <Button
                                  variant="outline"
                                  onClick={() => handleStatusChange(order.id, "created")}
                                  className="flex items-center justify-center gap-2"
                                >
                                  <Clock className="h-4 w-4" />
                                  Создан
                                </Button>
                                <Button
                                  variant="outline"
                                  onClick={() => handleStatusChange(order.id, "processing")}
                                  className="flex items-center justify-center gap-2"
                                >
                                  <Clock className="h-4 w-4" />В обработке
                                </Button>
                                <Button
                                  variant="outline"
                                  onClick={() => handleStatusChange(order.id, "packaging")}
                                  className="flex items-center justify-center gap-2"
                                >
                                  <Package className="h-4 w-4" />
                                  Сборка
                                </Button>
                                <Button
                                  variant="outline"
                                  onClick={() => handleStatusChange(order.id, "finding_courier")}
                                  className="flex items-center justify-center gap-2"
                                >
                                  <Search className="h-4 w-4" />
                                  Поиск курьера
                                </Button>
                                <Button
                                  variant="outline"
                                  onClick={() => handleStatusChange(order.id, "in_delivery")}
                                  className="flex items-center justify-center gap-2"
                                >
                                  <Truck className="h-4 w-4" />В пути
                                </Button>
                                <Button
                                  variant="outline"
                                  onClick={() => handleStatusChange(order.id, "delivered")}
                                  className="flex items-center justify-center gap-2 bg-green-50 text-green-600 hover:bg-green-100 hover:text-green-700"
                                >
                                  <CheckCircle className="h-4 w-4" />
                                  Доставлен
                                </Button>
                                <Button
                                  variant="outline"
                                  onClick={() => handleStatusChange(order.id, "cancelled")}
                                  className="flex items-center justify-center gap-2 bg-red-50 text-red-600 hover:bg-red-100 hover:text-red-700 col-span-2"
                                >
                                  <XCircle className="h-4 w-4" />
                                  Отменен
                                </Button>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <Accordion type="single" collapsible>
                      <AccordionItem value="details">
                        <AccordionTrigger>Информация о заказе</AccordionTrigger>
                        <AccordionContent>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-medium mb-2">Контактная информация</h4>
                              <div className="space-y-1">
                                <p>
                                  <span className="text-muted-foreground">Имя:</span> {order.name}
                                </p>
                                <p>
                                  <span className="text-muted-foreground">Телефон:</span> {order.phone}
                                </p>
                                <p>
                                  <span className="text-muted-foreground">Адрес:</span> {order.address}
                                </p>
                                <p>
                                  <span className="text-muted-foreground">Способ оплаты:</span>{" "}
                                  {order.paymentMethod === "cash" ? "Наличными при получении" : "Онлайн"}
                                </p>
                              </div>
                            </div>
                            <div>
                              <h4 className="font-medium mb-2">Товары</h4>
                              <div className="space-y-1">
                                {order.items.map((item: any, index: number) => (
                                  <p key={index}>
                                    {item.name} - {item.quantity} кг × {item.price} ₽ = {item.price * item.quantity} ₽
                                  </p>
                                ))}
                              </div>
                              <div className="mt-4 pt-2 border-t">
                                <p>
                                  <span className="text-muted-foreground">Сумма товаров:</span> {order.totalPrice} ₽
                                </p>
                                {order.discount > 0 && (
                                  <p className="text-green-600">
                                    <span>Скидка:</span> -{order.discount} ₽
                                  </p>
                                )}
                                <p>
                                  <span className="text-muted-foreground">Доставка:</span> {order.deliveryCost} ₽
                                </p>
                                <p className="font-bold">
                                  <span>Итого:</span> {order.finalPrice} ₽
                                </p>
                              </div>
                            </div>
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                      <AccordionItem value="status">
                        <AccordionTrigger>История статусов</AccordionTrigger>
                        <AccordionContent>
                          <div className="space-y-2">
                            {order.statusHistory.map((status: any, index: number) => (
                              <div key={index} className="flex items-center justify-between">
                                <Badge variant="outline" className="flex items-center gap-1">
                                  {status.status === "created" && <Clock className="h-3 w-3" />}
                                  {status.status === "processing" && <Clock className="h-3 w-3" />}
                                  {status.status === "packaging" && <Package className="h-3 w-3" />}
                                  {status.status === "finding_courier" && <Search className="h-3 w-3" />}
                                  {status.status === "in_delivery" && <Truck className="h-3 w-3" />}
                                  {status.status === "delivered" && <CheckCircle className="h-3 w-3" />}
                                  {status.status === "cancelled" && <XCircle className="h-3 w-3" />}
                                  {status.status === "created" && "Создан"}
                                  {status.status === "processing" && "В обработке"}
                                  {status.status === "packaging" && "Сборка"}
                                  {status.status === "finding_courier" && "Поиск курьера"}
                                  {status.status === "in_delivery" && "В пути"}
                                  {status.status === "delivered" && "Доставлен"}
                                  {status.status === "cancelled" && "Отменен"}
                                </Badge>
                                <span className="text-sm text-muted-foreground">
                                  {formatDate(new Date(status.timestamp))}
                                </span>
                              </div>
                            ))}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

