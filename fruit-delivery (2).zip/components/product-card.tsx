"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useCart } from "@/hooks/use-cart"
import type { Product } from "@/lib/types"
import { ShoppingCart, Plus, Minus } from "lucide-react"
import { useState } from "react"
import { Badge } from "@/components/ui/badge"

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const { toast } = useToast()
  const { addItem, items } = useCart()
  const [isHovered, setIsHovered] = useState(false)

  const cartItem = items.find((item) => item.id === product.id)
  const quantity = cartItem ? cartItem.quantity : 0

  const handleAddToCart = () => {
    addItem(product)
    toast({
      title: "Товар добавлен в корзину",
      description: `${product.name} добавлен в корзину`,
    })
  }

  return (
    <Card
      className="overflow-hidden transition-all duration-300 hover:shadow-lg group card-hover"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-48 overflow-hidden">
        <Image
          src={product.image || "/placeholder.svg?height=200&width=300"}
          alt={product.name}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {quantity > 0 && <Badge className="absolute top-2 right-2 bg-primary">В корзине: {quantity} кг</Badge>}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>
      <CardContent className="p-4">
        <h3 className="font-medium text-lg">{product.name}</h3>
        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{product.description}</p>
        <div className="mt-2 font-bold text-lg text-primary">{product.price} ₽/кг</div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        {quantity === 0 ? (
          <Button onClick={handleAddToCart} className="w-full group-hover:bg-primary/90 transition-colors">
            <ShoppingCart className="h-4 w-4 mr-2" />В корзину
          </Button>
        ) : (
          <div className="flex items-center justify-between w-full">
            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9"
              onClick={() => addItem({ ...product, quantity: -0.5 })}
            >
              <Minus className="h-4 w-4" />
            </Button>
            <span className="font-medium">{quantity} кг</span>
            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9"
              onClick={() => addItem({ ...product, quantity: 0.5 })}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        )}
      </CardFooter>
    </Card>
  )
}

