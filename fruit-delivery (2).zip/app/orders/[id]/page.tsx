"use client"

import { useEffect, useState } from "react"
import { useOrders } from "@/hooks/use-orders"
import { useAuth } from "@/hooks/use-auth"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2, ShoppingBag, ArrowLeft, Calendar, MapPin, CreditCard, Phone, User } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { formatDate } from "@/lib/utils"
import type { Order } from "@/lib/types"

export default function OrderDetailsPage({ params }: { params: { id: string } }) {
  const { getOrderById, loading } = useOrders()
  const { isAuthenticated } = useAuth()
  const router = useRouter()
  const [order, setOrder] = useState<Order | undefined>(undefined)

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth/login?redirect=/orders")
      return
    }

    if (params.id) {
      const foundOrder = getOrderById(params.id)
      if (foundOrder) {
        setOrder(foundOrder)
      } else {
        // Если заказ не найден, перенаправляем на страницу со всеми заказами
        router.push("/orders")
      }
    }
  }, [isAuthenticated, params.id, getOrderById, router])

  if (!isAuthenticated) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="max-w-md mx-auto">
          <div className="mb-6 flex justify-center">
            <div className="p-6 bg-muted/50 rounded-full">
              <ShoppingBag className="h-12 w-12 text-muted-foreground" />
            </div>
          </div>
          <h1 className="text-3xl font-bold mb-4">Требуется авторизация</h1>
          <p className="text-muted-foreground mb-8">Для просмотра деталей заказа необходимо войти в систему</p>
          <Button asChild size="lg">
            <Link href={`/auth/login?redirect=/orders/${params.id}`}>
              Войти в систему
              <ArrowLeft className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  if (loading || !order) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
        <p className="text-muted-foreground">Загрузка информации о заказе...</p>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-6">
        <Button variant="outline" asChild>
          <Link href="/orders">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Назад к заказам
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-2xl">Заказ #{order.id.slice(0, 8)}</CardTitle>
                  <CardDescription className="flex items-center mt-1">
                    <Calendar className="h-4 w-4 mr-1" />
                    {formatDate(new Date(order.date))}
                  </CardDescription>
                </div>
                <Badge
                  className={
                    order.status === "completed"
                      ? "bg-green-500"
                      : order.status === "cancelled"
                        ? "bg-red-500"
                        : "bg-amber-500"
                  }
                >
                  {order.status === "completed" ? "Выполнен" : order.status === "cancelled" ? "Отменен" : "В обработке"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <h3 className="font-medium text-lg mb-4">Товары в заказе</h3>
              <div className="space-y-4 divide-y">
                {order.items.map((item) => (
                  <div key={item.id} className="pt-4 first:pt-0 flex items-center gap-4">
                    <div className="relative h-16 w-16 rounded overflow-hidden flex-shrink-0">
                      <Image
                        src={item.image || "/placeholder.svg?height=100&width=100"}
                        alt={item.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">{item.name}</h4>
                      <p className="text-sm text-muted-foreground">{item.price} ₽ за кг</p>
                    </div>
                    <div className="text-sm">{item.quantity} кг</div>
                    <div className="w-24 text-right font-medium">{item.price * item.quantity} ₽</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Информация о заказе</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium mb-2 flex items-center">
                  <User className="h-4 w-4 mr-2" />
                  Получатель
                </h3>
                <p className="text-sm">{order.customerInfo.name}</p>
                <p className="text-sm flex items-center mt-1">
                  <Phone className="h-4 w-4 mr-2" />
                  {order.customerInfo.phone}
                </p>
              </div>

              <div>
                <h3 className="font-medium mb-2 flex items-center">
                  <MapPin className="h-4 w-4 mr-2" />
                  Адрес доставки
                </h3>
                <p className="text-sm">{order.customerInfo.address}</p>
                {order.customerInfo.floor && <p className="text-sm mt-1">Этаж: {order.customerInfo.floor}</p>}
                <p className="text-sm mt-1">
                  Тип доставки: {order.customerInfo.deliveryType === "door" ? "До двери" : "До подъезда"}
                </p>
              </div>

              <div>
                <h3 className="font-medium mb-2 flex items-center">
                  <CreditCard className="h-4 w-4 mr-2" />
                  Способ оплаты
                </h3>
                <p className="text-sm">
                  {order.customerInfo.paymentMethod === "cash" ? "Наличными при получении" : "Онлайн"}
                </p>
              </div>

              {order.customerInfo.comment && (
                <div>
                  <h3 className="font-medium mb-2">Комментарий</h3>
                  <p className="text-sm">{order.customerInfo.comment}</p>
                </div>
              )}

              <div className="pt-4 border-t">
                <h3 className="font-medium mb-2">Сумма заказа</h3>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Товары ({order.items.length}):</span>
                    <span>{order.totalPrice} ₽</span>
                  </div>
                  {order.discount > 0 && (
                    <div className="flex justify-between text-sm text-green-600">
                      <span>Скидка:</span>
                      <span>-{order.discount} ₽</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm">
                    <span>Доставка:</span>
                    <span>{order.deliveryCost} ₽</span>
                  </div>
                  <div className="flex justify-between font-bold mt-2 text-lg">
                    <span>Итого:</span>
                    <span>{order.finalTotal} ₽</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

