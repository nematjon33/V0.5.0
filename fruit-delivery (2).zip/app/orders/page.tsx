"use client"

import { useState, useEffect } from "react"
import { useOrders } from "@/hooks/use-orders"
import { useAuth } from "@/hooks/use-auth"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, ShoppingBag, ArrowRight } from "lucide-react"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import Image from "next/image"
import { useBonusCard } from "@/hooks/use-bonus-card"
import OrderStatus from "@/components/order-status"
import { useReviews } from "@/hooks/use-reviews"

export default function OrdersPage() {
  const { getUserOrders, loading } = useOrders()
  const { isAuthenticated } = useAuth()
  const router = useRouter()
  const { bonusCard } = useBonusCard()
  const { addReview } = useReviews()
  const [orders, setOrders] = useState(getUserOrders())

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth/login")
    } else {
      setOrders(getUserOrders())
    }
  }, [isAuthenticated, getUserOrders, router])

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!isAuthenticated) {
    return null // Редирект обрабатывается в useEffect
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold animate-text-gradient bg-gradient-to-r from-primary via-green-500 to-primary bg-[length:200%_auto] bg-clip-text text-transparent">
            История заказов
          </h1>
          <p className="text-muted-foreground mt-1">Ваши заказы и их статус</p>
        </div>

        {bonusCard && (
          <Card className="mt-4 md:mt-0 w-full md:w-auto">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <div className="bg-primary/10 p-2 rounded-full">
                  <ShoppingBag className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium">Ваша скидка: {bonusCard.discountPercent}%</p>
                  <p className="text-xs text-muted-foreground">Сумма покупок: {bonusCard.totalSpent} ₽</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-12">
          <ShoppingBag className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-xl font-bold mb-2">У вас пока нет заказов</h2>
          <p className="text-muted-foreground mb-6">Перейдите в каталог, чтобы сделать первый заказ</p>
          <Button asChild>
            <Link href="/catalog">
              Перейти в каталог
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      ) : (
        <Tabs defaultValue="all" className="mb-8">
          <TabsList className="mb-6">
            <TabsTrigger value="all">Все заказы</TabsTrigger>
            <TabsTrigger value="active">Активные</TabsTrigger>
            <TabsTrigger value="delivered">Доставленные</TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <OrdersList orders={orders} />
          </TabsContent>

          <TabsContent value="active">
            <OrdersList
              orders={orders.filter((order) => order.status !== "delivered" && order.status !== "cancelled")}
            />
          </TabsContent>

          <TabsContent value="delivered">
            <OrdersList orders={orders.filter((order) => order.status === "delivered")} />
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

function OrdersList({ orders }: { orders: any[] }) {
  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <Card key={order.id} className="overflow-hidden">
          <CardHeader className="bg-muted/30 pb-4">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <div>
                <CardTitle className="text-lg">Заказ #{order.id.split("-")[1]}</CardTitle>
                <CardDescription>{formatDate(new Date(order.date))}</CardDescription>
              </div>
              <div className="flex flex-col md:flex-row items-start md:items-center gap-2 mt-2 md:mt-0">
                <OrderStatus status={order.status} compact />
                <div className="font-bold">{order.finalPrice} ₽</div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <OrderStatus status={order.status} statusHistory={order.statusHistory} />

            <Accordion type="single" collapsible className="mt-4">
              <AccordionItem value="items">
                <AccordionTrigger>Товары в заказе ({order.items.length})</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3">
                    {order.items.map((item: any) => (
                      <div key={item.id} className="flex items-center gap-3">
                        <div className="relative h-12 w-12 rounded overflow-hidden flex-shrink-0">
                          <Image
                            src={item.image || "/placeholder.svg?height=100&width=100"}
                            alt={item.name}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{item.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {item.quantity} кг × {item.price} ₽
                          </p>
                        </div>
                        <div className="font-medium">{item.price * item.quantity} ₽</div>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="details">
                <AccordionTrigger>Детали заказа</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Имя:</span>
                      <span>{order.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Телефон:</span>
                      <span>{order.phone}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Адрес:</span>
                      <span>{order.address}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Способ оплаты:</span>
                      <span>{order.paymentMethod === "cash" ? "Наличными при получении" : "Онлайн"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Сумма товаров:</span>
                      <span>{order.totalPrice} ₽</span>
                    </div>
                    {order.discount > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span>Скидка:</span>
                        <span>-{order.discount} ₽</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Доставка:</span>
                      <span>{order.deliveryCost === 0 ? "Бесплатно" : `${order.deliveryCost} ₽`}</span>
                    </div>
                    <div className="flex justify-between font-bold pt-2 border-t">
                      <span>Итого:</span>
                      <span>{order.finalPrice} ₽</span>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            {order.status === "delivered" && !order.reviewed && (
              <div className="mt-4 pt-4 border-t">
                <Link href={`/reviews/add?orderId=${order.id}`}>
                  <Button className="w-full">Оставить отзыв</Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

