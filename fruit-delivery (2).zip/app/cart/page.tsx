"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { useCart } from "@/hooks/use-cart"
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, Tag, Check } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useOrders } from "@/hooks/use-orders"
import { useRouter } from "next/navigation"
import { useBonusCard } from "@/hooks/use-bonus-card"
import { useAuth } from "@/hooks/use-auth"
import { calculateDeliveryCost } from "@/lib/local-storage"

// Расширенная база данных улиц Челябинска
const STREETS = [
  "Артиллерийская",
  "Марченко",
  "Ленина",
  "Комсомольский проспект",
  "Свободы",
  "Молодогвардейцев",
  "Чайковского",
  "Братьев Кашириных",
  "Университетская Набережная",
  "Воровского",
  "Доватора",
  "Гагарина",
  "Блюхера",
  "Энгельса",
  "Худякова",
  "Академика Королева",
  "Академика Макеева",
  "Академика Павлова",
  "Академика Сахарова",
  "Александра Шмакова",
  "Бажова",
  "Барбюса",
  "Бейвеля",
  "Белостоцкого",
  "Бородина",
  "Братьев Кашириных",
  "Бурденко",
  "Василевского",
  "Ворошилова",
  "Гагарина",
  "Героев Танкограда",
  "Горького",
  "Дзержинского",
  "Доватора",
  "Елькина",
  "Жукова",
  "Захаренко",
  "Калинина",
  "Карла Либкнехта",
  "Карла Маркса",
  "Кирова",
  "Коммуны",
  "Комсомольский проспект",
  "Косарева",
  "Красная",
  "Краснознаменная",
  "Кузнецова",
  "Курчатова",
  "Ленина",
  "Лесопарковая",
  "Лобкова",
  "Марченко",
  "Масленникова",
  "Машиностроителей",
  "Мира",
  "Молодогвардейцев",
  "Монакова",
  "Набережная",
  "Новороссийская",
  "Октябрьская",
  "Орджоникидзе",
  "Островского",
  "Победы",
  "Пограничная",
  "Пушкина",
  "Российская",
  "Руставели",
  "Салютная",
  "Свердловский проспект",
  "Свободы",
  "Северо-Крымская",
  "Советская",
  "Солнечная",
  "Сони Кривой",
  "Сталеваров",
  "Сулимова",
  "Тарасова",
  "Татищева",
  "Тимирязева",
  "Труда",
  "Университетская Набережная",
  "Цвиллинга",
  "Чайковского",
  "Чапаева",
  "Чичерина",
  "Шаумяна",
  "Шоссе Металлургов",
  "Энгельса",
  "Энтузиастов",
  "Ярославская",
  "40-летия Победы",
  "50-летия ВЛКСМ",
  "60-летия Октября",
  "Агалакова",
  "Артиллерийская",
  "Барбюса",
  "Бейвеля",
]

// Промокоды
const PROMO_CODES = {
  fresh10: { discount: 0.1, description: "Скидка 10% на все товары" },
}

export default function CartPage() {
  const { toast } = useToast()
  const { items, removeItem, updateQuantity, clearCart } = useCart()
  const { addOrder } = useOrders()
  const { bonusCard } = useBonusCard()
  const { user, isAuthenticated } = useAuth()
  const router = useRouter()

  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [address, setAddress] = useState("")
  const [floor, setFloor] = useState("")
  const [deliveryType, setDeliveryType] = useState("entrance")
  const [paymentMethod, setPaymentMethod] = useState("cash")
  const [comment, setComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [filteredStreets, setFilteredStreets] = useState<string[]>([])
  const [promoCode, setPromoCode] = useState("")
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; discount: number } | null>(null)
  const [isPromoValid, setIsPromoValid] = useState<boolean | null>(null)
  const [useBonus, setUseBonus] = useState(true)

  // Заполняем данные пользователя, если он авторизован
  useEffect(() => {
    if (isAuthenticated && user) {
      setName(user.name || "")
      setPhone(user.phone || "")
    }
  }, [isAuthenticated, user])

  const totalPrice = items.reduce((total, item) => total + item.price * item.quantity, 0)

  // Расчет стоимости доставки с использованием новой системы
  const deliveryCost = calculateDeliveryCost(totalPrice)
  const doorDeliveryCost = deliveryType === "door" ? 50 : 0

  // Определяем, бесплатная ли доставка
  const freeDelivery = deliveryCost === 0

  // Расчет скидки по промокоду
  const promoDiscount = appliedPromo ? Math.round(totalPrice * appliedPromo.discount) : 0

  // Расчет скидки по бонусной карте
  const bonusDiscount =
    useBonus && bonusCard && bonusCard.discountPercent > 0
      ? Math.round(totalPrice * (bonusCard.discountPercent / 100))
      : 0

  // Общая скидка
  const totalDiscount = promoDiscount + bonusDiscount

  // Итоговая сумма с учетом скидки
  const finalTotal = totalPrice - totalDiscount + deliveryCost + doorDeliveryCost

  // Фильтрация улиц при вводе
  useEffect(() => {
    if (address.length > 2) {
      const searchTerm = address.toLowerCase()
      const filtered = STREETS.filter((street) => street.toLowerCase().includes(searchTerm))
      setFilteredStreets(filtered)
    } else {
      setFilteredStreets([])
    }
  }, [address])

  // Проверка промокода
  const checkPromoCode = () => {
    if (!promoCode) return

    const promo = PROMO_CODES[promoCode as keyof typeof PROMO_CODES]

    if (promo) {
      setAppliedPromo({ code: promoCode, discount: promo.discount })
      setIsPromoValid(true)
      toast({
        title: "Промокод применен",
        description: promo.description,
      })
    } else {
      setIsPromoValid(false)
      toast({
        title: "Недействительный промокод",
        description: "Введенный промокод не найден или истек срок его действия",
        variant: "destructive",
      })
    }
  }

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!isAuthenticated) {
      toast({
        title: "Требуется авторизация",
        description: "Для оформления заказа необходимо войти в систему",
        variant: "destructive",
      })
      router.push("/auth/login?redirect=/cart")
      return
    }

    if (!name || !phone || !address) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, заполните все обязательные поля",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Формируем данные заказа
      const orderData = {
        items: [...items],
        totalPrice,
        discount: totalDiscount,
        finalPrice: totalPrice - totalDiscount,
        deliveryCost: deliveryCost + doorDeliveryCost,
        address,
        phone,
        name,
        paymentMethod,
        customerInfo: {
          name,
          phone,
          address,
          floor: floor || undefined,
          deliveryType: deliveryType as "entrance" | "door",
          paymentMethod: paymentMethod as "cash" | "online",
          comment: comment || undefined,
        },
      }

      // Отправляем заказ
      const order = await addOrder(orderData)

      toast({
        title: "Заказ оформлен",
        description: "Ваш заказ успешно оформлен. Мы свяжемся с вами в ближайшее время.",
      })

      // Очищаем корзину
      clearCart()

      // Перенаправляем на страницу с историей заказов
      router.push(`/orders/${order.id}`)
    } catch (error) {
      console.error("Ошибка при оформлении заказа:", error)
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при оформлении заказа. Пожалуйста, попробуйте еще раз.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="max-w-md mx-auto">
          <div className="mb-6 flex justify-center">
            <div className="p-6 bg-muted/50 rounded-full">
              <ShoppingBag className="h-12 w-12 text-muted-foreground" />
            </div>
          </div>
          <h1 className="text-3xl font-bold mb-4 animate-text-gradient bg-gradient-to-r from-primary via-green-500 to-primary bg-[length:200%_auto] bg-clip-text text-transparent">
            Корзина пуста
          </h1>
          <p className="text-muted-foreground mb-8">Добавьте товары из каталога, чтобы оформить заказ</p>
          <Button asChild size="lg" className="hover:scale-105 transition-transform">
            <Link href="/catalog" className="flex items-center gap-2">
              Перейти в каталог
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8 animate-text-gradient bg-gradient-to-r from-primary via-green-500 to-primary bg-[length:200%_auto] bg-clip-text text-transparent">
        Корзина
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="border rounded-lg overflow-hidden shadow-sm">
            <div className="bg-muted/50 px-4 py-3 font-medium">Товары в корзине ({items.length})</div>
            <div className="divide-y">
              {items.map((item) => (
                <div key={item.id} className="p-4 flex items-center gap-4">
                  <div className="relative h-16 w-16 rounded overflow-hidden flex-shrink-0">
                    <Image
                      src={item.image || "/placeholder.svg?height=100&width=100"}
                      alt={item.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium">{item.name}</h3>
                    <p className="text-sm text-muted-foreground">{item.price} ₽ за кг</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 hover:scale-105 transition-transform"
                      onClick={() => updateQuantity(item.id, Math.max(0.5, item.quantity - 0.5))}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-12 text-center">{item.quantity} кг</span>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 hover:scale-105 transition-transform"
                      onClick={() => updateQuantity(item.id, item.quantity + 0.5)}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="w-24 text-right font-medium">{item.price * item.quantity} ₽</div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground hover:scale-105 transition-transform"
                    onClick={() => removeItem(item.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <div className="border rounded-lg p-6 sticky top-4 shadow-sm">
            <h2 className="text-xl font-bold mb-4">Оформление заказа</h2>

            <div className="space-y-3 py-4 border-t border-b mb-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Товары:</span>
                <span>{totalPrice} ₽</span>
              </div>

              {bonusDiscount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Бонусная скидка ({bonusCard?.discountPercent}%):</span>
                  <span>-{bonusDiscount} ₽</span>
                </div>
              )}

              {promoDiscount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Промокод:</span>
                  <span>-{promoDiscount} ₽</span>
                </div>
              )}

              <div className="flex justify-between">
                <span className="text-muted-foreground">Доставка:</span>
                <span>{freeDelivery ? <span className="text-green-600">Бесплатно</span> : `${deliveryCost} ₽`}</span>
              </div>

              {deliveryType === "door" && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Доставка до двери:</span>
                  <span>50 ₽</span>
                </div>
              )}

              <div className="flex justify-between font-bold text-lg pt-2">
                <span>Итого:</span>
                <span>{finalTotal} ₽</span>
              </div>
            </div>

            <form onSubmit={handleSubmitOrder} className="space-y-4">
              <div>
                <Label htmlFor="name">Имя*</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
              </div>

              <div>
                <Label htmlFor="phone">Телефон*</Label>
                <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
              </div>

              <div>
                <Label htmlFor="address">Адрес доставки*</Label>
                <div className="relative">
                  <Input
                    id="address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    required
                    autoComplete="off"
                  />
                  {filteredStreets.length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                      {filteredStreets.map((street) => (
                        <div
                          key={street}
                          className="px-4 py-2 cursor-pointer hover:bg-muted"
                          onClick={() => {
                            setAddress(`ул. ${street}, `)
                            setFilteredStreets([])
                          }}
                        >
                          ул. {street}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="floor">Этаж</Label>
                <Input id="floor" value={floor} onChange={(e) => setFloor(e.target.value)} />
              </div>

              <div>
                <Label>Тип доставки</Label>
                <RadioGroup value={deliveryType} onValueChange={setDeliveryType} className="mt-2">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="entrance" id="entrance" />
                    <Label htmlFor="entrance" className="cursor-pointer">
                      До подъезда
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="door" id="door" />
                    <Label htmlFor="door" className="cursor-pointer">
                      До двери (+50₽)
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label>Способ оплаты</Label>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="mt-2">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="cash" id="cash" />
                    <Label htmlFor="cash" className="cursor-pointer">
                      Наличными при получении
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="online" id="online" />
                    <Label htmlFor="online" className="cursor-pointer">
                      Онлайн
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {bonusCard && bonusCard.discountPercent > 0 && (
                <div className="flex items-center space-x-2 pt-2 border-t">
                  <input
                    type="checkbox"
                    id="useBonus"
                    checked={useBonus}
                    onChange={(e) => setUseBonus(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                  />
                  <Label htmlFor="useBonus" className="cursor-pointer">
                    Использовать бонусную скидку ({bonusCard.discountPercent}%)
                  </Label>
                </div>
              )}

              <div>
                <Label htmlFor="promo">Промокод</Label>
                <div className="flex gap-2">
                  <Input
                    id="promo"
                    value={promoCode}
                    onChange={(e) => {
                      setPromoCode(e.target.value)
                      setIsPromoValid(null)
                    }}
                    placeholder="Введите промокод"
                    className={
                      isPromoValid === true ? "border-green-500" : isPromoValid === false ? "border-red-500" : ""
                    }
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={checkPromoCode}
                    disabled={!promoCode || isPromoValid === true}
                    className="hover:scale-105 transition-transform"
                  >
                    {isPromoValid === true ? <Check className="h-4 w-4 text-green-500" /> : <Tag className="h-4 w-4" />}
                  </Button>
                </div>
                {isPromoValid === true && (
                  <p className="text-xs text-green-600 mt-1">Промокод применен! Скидка: {promoDiscount} ₽</p>
                )}
                {isPromoValid === false && <p className="text-xs text-red-500 mt-1">Недействительный промокод</p>}
              </div>

              <div>
                <Label htmlFor="comment">Комментарий к заказу</Label>
                <Textarea id="comment" value={comment} onChange={(e) => setComment(e.target.value)} rows={3} />
              </div>

              <Button type="submit" className="w-full hover:scale-105 transition-transform" disabled={isSubmitting}>
                {isSubmitting ? "Оформление..." : "Оформить заказ"}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}

