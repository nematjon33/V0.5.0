"use client"

import { useState, useEffect } from "react"
import { useReviews } from "@/hooks/use-reviews"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Star, User, Calendar, AlertTriangle } from "lucide-react"
import Image from "next/image"
import { formatDate } from "@/lib/utils"

export default function ReviewsPage() {
  const { getApprovedReviews } = useReviews()
  const [reviews, setReviews] = useState<any[]>([])

  useEffect(() => {
    setReviews(getApprovedReviews())
  }, [getApprovedReviews])

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 animate-text-gradient bg-gradient-to-r from-primary via-green-500 to-primary bg-[length:200%_auto] bg-clip-text text-transparent">
        Отзывы наших клиентов
      </h1>

      {reviews.length === 0 ? (
        <div className="text-center py-12">
          <AlertTriangle className="h-12 w-12 mx-auto text-amber-500 mb-4" />
          <h2 className="text-xl font-bold mb-2">Пока нет отзывов</h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            Будьте первым, кто оставит отзыв о нашем сервисе. Ваше мнение очень важно для нас!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {reviews.map((review) => (
            <Card key={review.id}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg flex items-center">
                    <User className="h-5 w-5 mr-2 text-muted-foreground" />
                    {review.userName}
                  </CardTitle>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-5 w-5 ${
                          star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-200"
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <div className="text-sm text-muted-foreground flex items-center mt-1">
                  <Calendar className="h-4 w-4 mr-1" />
                  {formatDate(new Date(review.date))}
                </div>
              </CardHeader>
              <CardContent>
                <p className="mb-4">{review.text}</p>

                {review.images && review.images.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-4">
                    {review.images.map((image: string, index: number) => (
                      <div key={index} className="relative h-20 w-20 rounded overflow-hidden">
                        <Image
                          src={image || "/placeholder.svg"}
                          alt={`Фото ${index + 1}`}
                          fill
                          className="object-cover"
                        />
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

