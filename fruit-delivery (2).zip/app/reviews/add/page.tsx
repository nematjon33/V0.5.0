"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useOrders } from "@/hooks/use-orders"
import { useReviews } from "@/hooks/use-reviews"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Star, Upload, X, ArrowLeft } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function AddReviewPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const orderId = searchParams.get("orderId")
  const { getOrderById } = useOrders()
  const { addReview } = useReviews()
  const { isAuthenticated } = useAuth()
  const { toast } = useToast()

  const [order, setOrder] = useState<any>(null)
  const [rating, setRating] = useState(5)
  const [reviewText, setReviewText] = useState("")
  const [images, setImages] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth/login")
      return
    }

    if (orderId) {
      const foundOrder = getOrderById(orderId)
      if (foundOrder) {
        setOrder(foundOrder)
      } else {
        router.push("/orders")
      }
    } else {
      router.push("/orders")
    }
  }, [isAuthenticated, orderId, getOrderById, router])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    // Ограничение на 5 изображений
    if (images.length + files.length > 5) {
      toast({
        title: "Ошибка",
        description: "Можно загрузить максимум 5 изображений",
        variant: "destructive",
      })
      return
    }

    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        if (e.target?.result) {
          setImages((prev) => [...prev, e.target!.result as string])
        }
      }
      reader.readAsDataURL(file)
    })
  }

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!order) return

    if (rating < 1 || rating > 5) {
      setError("Пожалуйста, выберите оценку от 1 до 5 звезд")
      return
    }

    if (!reviewText.trim()) {
      setError("Пожалуйста, напишите текст отзыва")
      return
    }

    setIsSubmitting(true)

    try {
      await addReview({
        orderId: order.id,
        rating,
        text: reviewText,
        images: images.length > 0 ? images : undefined,
      })

      toast({
        title: "Отзыв отправлен",
        description: "Ваш отзыв отправлен на модерацию. Спасибо!",
      })

      router.push("/orders")
    } catch (error) {
      console.error("Ошибка при отправке отзыва:", error)
      setError("Не удалось отправить отзыв. Пожалуйста, попробуйте еще раз.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!order) return null

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button variant="outline" asChild>
          <Link href="/orders">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Назад к заказам
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Оставить отзыв</CardTitle>
          <CardDescription>
            Заказ #{order.id.split("-")[1]} от {new Date(order.date).toLocaleDateString()}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">Оценка</label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button key={star} type="button" onClick={() => setRating(star)} className="focus:outline-none">
                    <Star
                      className={`h-8 w-8 ${star <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Ваш отзыв</label>
              <Textarea
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                placeholder="Расскажите о вашем опыте..."
                rows={5}
                required
              />
              {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Фотографии (до 5 шт.)</label>
              <div className="flex flex-wrap gap-2 mb-2">
                {images.map((image, index) => (
                  <div key={index} className="relative h-24 w-24 rounded overflow-hidden">
                    <Image src={image || "/placeholder.svg"} alt={`Фото ${index + 1}`} fill className="object-cover" />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute top-1 right-1 bg-black/50 rounded-full p-1"
                    >
                      <X className="h-4 w-4 text-white" />
                    </button>
                  </div>
                ))}
                {images.length < 5 && (
                  <label className="h-24 w-24 border-2 border-dashed rounded flex items-center justify-center cursor-pointer hover:bg-muted/50 transition-colors">
                    <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" multiple />
                    <Upload className="h-6 w-6 text-muted-foreground" />
                  </label>
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Загрузите фотографии, чтобы поделиться своими впечатлениями
              </p>
            </div>

            <div className="pt-4">
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "Отправка..." : "Отправить отзыв"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

