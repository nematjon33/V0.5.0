"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Product } from "@/lib/types"
import { Loader2, Search, AlertTriangle, RefreshCw, ShoppingCart, Ban } from "lucide-react"
import Image from "next/image"
import { useCart } from "@/hooks/use-cart"
import { useProducts } from "@/hooks/use-products"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/hooks/use-auth"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Card, CardContent, CardFooter } from "@/components/ui/card"

export default function CatalogPage() {
  const { products, loading, refreshProducts, error } = useProducts()
  const [searchTerm, setSearchTerm] = useState("")
  const [retryCount, setRetryCount] = useState(0)
  const { addItem, items } = useCart()
  const { isAuthenticated } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  // Фильтрация товаров по категориям
  const vegetables = products.filter((product) => product.category === "vegetables" && product.inStock !== false)
  const fruits = products.filter((product) => product.category === "fruits" && product.inStock !== false)
  const dryFruits = products.filter((product) => product.category === "dryFruits" && product.inStock !== false)
  const drinks = products.filter((product) => product.category === "drinks" && product.inStock !== false)

  // Фильтрация товаров по поиску
  const filteredProducts = searchTerm
    ? products.filter(
        (product) =>
          (product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            product.description.toLowerCase().includes(searchTerm.toLowerCase())) &&
          product.inStock !== false,
      )
    : products.filter((product) => product.inStock !== false)

  // Мемоизированная функция обновления для предотвращения лишних ререндеров
  const handleRefresh = useCallback(() => {
    refreshProducts()
    setRetryCount((prev) => prev + 1)
  }, [refreshProducts])

  // Обновление данных при монтировании с оптимизацией производительности
  useEffect(() => {
    // Устанавливаем таймаут для предотвращения бесконечной загрузки
    const timeoutId = setTimeout(() => {
      handleRefresh()
    }, 100)

    return () => clearTimeout(timeoutId)
  }, [handleRefresh])

  // Функция для добавления товара в корзину
  const handleAddToCart = (product: Product) => {
    if (!isAuthenticated) {
      toast({
        title: "Требуется авторизация",
        description: "Для добавления товаров в корзину необходимо войти в систему",
        variant: "destructive",
      })
      router.push("/auth/login")
      return
    }

    addItem(product)
    toast({
      title: "Товар добавлен",
      description: `${product.name} добавлен в корзину`,
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold animate-text-gradient bg-gradient-to-r from-primary via-green-500 to-primary bg-[length:200%_auto] bg-clip-text text-transparent">
            Каталог товаров
          </h1>
          <p className="text-muted-foreground mt-1">Свежие овощи, фрукты и сухофрукты с доставкой</p>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Поиск товаров..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button
            variant="outline"
            onClick={handleRefresh}
            disabled={loading}
            className="flex items-center gap-2 hover:scale-105 transition-transform"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            Обновить
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
          <p className="text-muted-foreground">Загрузка каталога...</p>
          {retryCount > 1 && (
            <Alert className="mt-4 max-w-md">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Загрузка занимает больше времени, чем обычно</AlertTitle>
              <AlertDescription>
                Мы используем локальные данные для отображения каталога. Пожалуйста, подождите.
              </AlertDescription>
            </Alert>
          )}
        </div>
      ) : error ? (
        <Alert variant="destructive" className="mb-6">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Ошибка загрузки каталога</AlertTitle>
          <AlertDescription className="flex items-center gap-2">
            {error}
            <Button variant="outline" size="sm" onClick={handleRefresh} className="ml-2">
              Попробовать снова
            </Button>
          </AlertDescription>
        </Alert>
      ) : (
        <>
          {
            <Tabs defaultValue="all" className="mb-8">
              <TabsList className="bg-muted/30 p-1 rounded-full mb-6 overflow-x-auto flex-nowrap whitespace-nowrap">
                <TabsTrigger value="all" className="rounded-full">
                  Все товары
                </TabsTrigger>
                <TabsTrigger value="vegetables" className="rounded-full">
                  Овощи
                </TabsTrigger>
                <TabsTrigger value="fruits" className="rounded-full">
                  Фрукты
                </TabsTrigger>
                <TabsTrigger value="dryFruits" className="rounded-full">
                  Сухофрукты
                </TabsTrigger>
                <TabsTrigger value="drinks" className="rounded-full">
                  Напитки
                </TabsTrigger>
              </TabsList>

              <TabsContent value="all">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {filteredProducts.length > 0 ? (
                    filteredProducts.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        cartItem={items.find((item) => item.id === product.id)}
                        onAddToCart={handleAddToCart}
                      />
                    ))
                  ) : (
                    <div className="col-span-full text-center py-8">
                      <p className="text-muted-foreground">Товары не найдены</p>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="vegetables">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {vegetables.length > 0 ? (
                    vegetables.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        cartItem={items.find((item) => item.id === product.id)}
                        onAddToCart={handleAddToCart}
                      />
                    ))
                  ) : (
                    <div className="col-span-full text-center py-8">
                      <p className="text-muted-foreground">Товары не найдены</p>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="fruits">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {fruits.length > 0 ? (
                    fruits.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        cartItem={items.find((item) => item.id === product.id)}
                        onAddToCart={handleAddToCart}
                      />
                    ))
                  ) : (
                    <div className="col-span-full text-center py-8">
                      <p className="text-muted-foreground">Товары не найдены</p>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="dryFruits">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {dryFruits.length > 0 ? (
                    dryFruits.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        cartItem={items.find((item) => item.id === product.id)}
                        onAddToCart={handleAddToCart}
                      />
                    ))
                  ) : (
                    <div className="col-span-full text-center py-8">
                      <p className="text-muted-foreground">Товары не найдены</p>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="drinks">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {drinks.length > 0 ? (
                    drinks.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        cartItem={items.find((item) => item.id === product.id)}
                        onAddToCart={handleAddToCart}
                      />
                    ))
                  ) : (
                    <div className="col-span-full text-center py-8">
                      <p className="text-muted-foreground">Товары не найдены</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          }
        </>
      )}
    </div>
  )
}

// Компонент карточки товара
interface ProductCardProps {
  product: Product
  cartItem?: { quantity: number }
  onAddToCart: (product: Product) => void
}

function ProductCard({ product, cartItem, onAddToCart }: ProductCardProps) {
  const [quantity, setQuantity] = useState(1)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const handleIncrement = () => {
    setQuantity((prev) => prev + 1)
  }

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity((prev) => prev - 1)
    }
  }

  const handleNextImage = () => {
    if (product.images && product.images.length > 1) {
      setCurrentImageIndex((prev) => (prev + 1) % product.images.length)
    }
  }

  const displayImage =
    product.images && product.images.length > 0
      ? product.images[currentImageIndex]
      : product.image || "/placeholder.svg?height=200&width=300"

  return (
    <Card className="overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="relative h-40" onClick={handleNextImage}>
        <Image src={displayImage || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
        {product.images && product.images.length > 1 && (
          <div className="absolute bottom-2 right-2 bg-black/50 text-white text-xs px-2 py-1 rounded-full">
            {currentImageIndex + 1}/{product.images.length}
          </div>
        )}
        {product.category === "fruits" && (
          <Badge className="absolute top-2 right-2 bg-orange-500 hover:bg-orange-600">Фрукты</Badge>
        )}
        {product.category === "vegetables" && (
          <Badge className="absolute top-2 right-2 bg-green-500 hover:bg-green-600">Овощи</Badge>
        )}
        {product.category === "dryFruits" && (
          <Badge className="absolute top-2 right-2 bg-amber-500 hover:bg-amber-600">Сухофрукты</Badge>
        )}
        {product.category === "drinks" && (
          <Badge className="absolute top-2 right-2 bg-blue-500 hover:bg-blue-600">Напитки</Badge>
        )}
        {product.stock !== undefined && product.stock <= 5 && product.stock > 0 && (
          <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-600">Осталось: {product.stock} кг</Badge>
        )}
      </div>

      <CardContent className="p-3">
        <div className="text-xl font-bold">{product.price} ₽</div>
        <h3 className="font-medium text-base mt-1">{product.name}</h3>
        <p className="text-xs text-muted-foreground mt-1">1 кг</p>
      </CardContent>

      <CardFooter className="p-3 pt-0">
        {product.inStock === false || (product.stock !== undefined && product.stock <= 0) ? (
          <Button className="w-full bg-gray-400 hover:bg-gray-400 cursor-not-allowed" disabled>
            <Ban className="mr-2 h-4 w-4" />
            Нет в наличии
          </Button>
        ) : cartItem ? (
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center border rounded-md">
              <button
                className="w-8 h-8 flex items-center justify-center text-muted-foreground"
                onClick={handleDecrement}
              >
                -
              </button>
              <span className="w-8 text-center">{quantity}</span>
              <button
                className="w-8 h-8 flex items-center justify-center text-muted-foreground"
                onClick={handleIncrement}
              >
                +
              </button>
            </div>
            <Button
              size="sm"
              className="bg-primary hover:bg-primary/90 hover:scale-105 transition-transform"
              onClick={() => onAddToCart({ ...product, quantity })}
            >
              В корзину
            </Button>
          </div>
        ) : (
          <Button
            className="w-full bg-primary hover:bg-primary/90 hover:scale-105 transition-transform"
            onClick={() => onAddToCart(product)}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />В корзину
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

