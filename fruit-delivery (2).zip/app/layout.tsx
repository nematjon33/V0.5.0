import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { Providers } from "./providers"
import { Toaster } from "@/components/ui/toaster"
import FloatingCart from "@/components/floating-cart"
import ScrollToTop from "@/components/scroll-to-top"
import InstallPrompt from "@/components/install-prompt"

const inter = Inter({ subsets: ["latin", "cyrillic"] })

export const metadata: Metadata = {
  title: "Olucha-fresh - доставка свежих овощей, фруктов и сухофруктов в Челябинске",
  description:
    "Заказывайте свежие овощи, фрукты и сухофрукты с доставкой на дом в Челябинске. Бесплатная доставка от 2399₽",
  keywords:
    "доставка фруктов, доставка овощей, Челябинск, свежие фрукты, свежие овощи, сухофрукты, бесплатная доставка, купить фрукты, купить овощи, доставка еды, здоровое питание, фрукты с доставкой, овощи с доставкой",
  authors: [{ name: "Olucha-fresh", url: "https://olucha-fresh.ru" }],
  creator: "Olucha-fresh",
  publisher: "Olucha-fresh",
  formatDetection: {
    email: true,
    address: true,
    telephone: true,
  },
  openGraph: {
    title: "Olucha-fresh - доставка свежих овощей, фруктов и сухофруктов в Челябинске",
    description:
      "Заказывайте свежие овощи, фрукты и сухофрукты с доставкой на дом в Челябинске. Бесплатная доставка от 2399₽",
    url: "https://olucha-fresh.ru",
    siteName: "Olucha-fresh",
    locale: "ru_RU",
    type: "website",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ru">
      <head>
        <meta name="robots" content="index, follow" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="canonical" href="https://olucha-fresh.ru" />
        <meta name="theme-color" content="#22c55e" />
        <link rel="manifest" href="/manifest.json" />
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <Providers>
            <div className="flex min-h-screen flex-col">
              <Header />
              <main className="flex-1">{children}</main>
              <Footer />
            </div>
            <FloatingCart />
            <ScrollToTop />
            <InstallPrompt />
            <Toaster />
          </Providers>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'