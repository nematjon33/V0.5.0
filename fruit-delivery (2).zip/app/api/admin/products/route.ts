import { type NextRequest, NextResponse } from "next/server"

// В реальном приложении здесь был бы код для работы с базой данных
// или Google Sheets API для обновления данных

export async function POST(request: NextRequest) {
  try {
    const product = await request.json()

    // Здесь должен быть код для сохранения товара
    // Например, добавление в базу данных или обновление Google Sheets

    return NextResponse.json({ success: true, product })
  } catch (error) {
    console.error("Error saving product:", error)
    return NextResponse.json({ error: "Failed to save product" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Product ID is required" }, { status: 400 })
    }

    // Здесь должен быть код для удаления товара
    // Например, удаление из базы данных или обновление Google Sheets

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting product:", error)
    return NextResponse.json({ error: "Failed to delete product" }, { status: 500 })
  }
}

