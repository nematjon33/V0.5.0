import { NextResponse } from "next/server"
import { isSupabaseAvailable } from "@/lib/supabase-server"

export async function GET() {
  try {
    const available = await isSupabaseAvailable()
    return NextResponse.json({ available })
  } catch (error) {
    console.error("Error checking Supabase availability:", error)
    return NextResponse.json({ available: false })
  }
}

