import { NextResponse } from "next/server"
import { products as fallbackProducts } from "@/lib/products"
import { fetchProducts, addProduct } from "@/lib/supabase-server"

export async function GET() {
  try {
    // Пытаемся получить продукты из Supabase
    const products = await fetchProducts()

    // Возвращаем полученные продукты
    return NextResponse.json({ products, source: products === fallbackProducts ? "local" : "supabase" })
  } catch (error) {
    console.error("Error fetching products:", error)
    // В случае ошибки возвращаем локальные данные
    return NextResponse.json(
      { products: fallbackProducts, source: "local", error: "Failed to fetch from database" },
      { status: 200 },
    )
  }
}

export async function POST(request: Request) {
  try {
    const product = await request.json()
    const savedProduct = await addProduct(product)
    return NextResponse.json({ success: true, product: savedProduct })
  } catch (error) {
    console.error("Error adding product:", error)
    return NextResponse.json({ error: "Failed to add product" }, { status: 500 })
  }
}

