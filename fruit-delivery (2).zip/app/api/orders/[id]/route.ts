import { NextResponse } from "next/server"
import { updateOrderStatus } from "@/lib/supabase-server"
import { sendStatusUpdateNotification } from "@/lib/telegram"

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const { status, statusHistory } = await request.json()
    const id = params.id

    if (!id || !status) {
      return NextResponse.json({ error: "Order ID and status are required" }, { status: 400 })
    }

    // Обновляем статус заказа в Supabase
    const updated = await updateOrderStatus(id, status, statusHistory)

    // Отправляем уведомление в Telegram об изменении статуса
    // Передаем объект с полным заказом или хотя бы с id
    try {
      // Исправляем: передаем объект с id вместо просто {id}
      await sendStatusUpdateNotification({ id, status }, status)
    } catch (telegramError) {
      console.error("Error sending Telegram notification:", telegramError)
    }

    return NextResponse.json({ success: updated })
  } catch (error) {
    console.error("Error updating order status:", error)
    return NextResponse.json({ error: "Failed to update order status" }, { status: 500 })
  }
}

