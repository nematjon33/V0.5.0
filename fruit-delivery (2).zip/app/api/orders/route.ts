import { NextResponse } from "next/server"
import { saveOrder, fetchOrders } from "@/lib/supabase-server"
import { sendOrderNotification } from "@/lib/telegram"

export async function POST(request: Request) {
  try {
    const order = await request.json()

    // Сохраняем заказ в Supabase
    const savedOrder = await saveOrder(order)

    // Отправляем уведомление в Telegram
    await sendOrderNotification(order)

    return NextResponse.json({ success: true, order: savedOrder || order })
  } catch (error) {
    console.error("Error saving order:", error)
    return NextResponse.json({ error: "Failed to save order" }, { status: 500 })
  }
}

export async function GET() {
  try {
    // Получаем заказы из Supabase
    const orders = await fetchOrders()

    return NextResponse.json({ orders })
  } catch (error) {
    console.error("Error fetching orders:", error)
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 })
  }
}

