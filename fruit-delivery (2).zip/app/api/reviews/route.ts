import { NextResponse } from "next/server"
import { saveReview, fetchReviews } from "@/lib/supabase-server"
import { getReviews, addReview as addReviewToStorage } from "@/lib/local-storage"

export async function POST(request: Request) {
  try {
    const review = await request.json()

    // Always save to local storage
    const localReview = addReviewToStorage(review)

    // Try to save to Supabase, but don't fail if it doesn't work
    let savedReview = localReview
    try {
      savedReview = (await saveReview(review)) || localReview
    } catch (supabaseError) {
      // Don't log the error if it's about the missing table
      if (!(supabaseError instanceof Error && supabaseError.message.includes("does not exist"))) {
        console.error("Error saving review to Supabase:", supabaseError)
      }
      // Continue with local review if Supabase fails
    }

    return NextResponse.json({ success: true, review: savedReview })
  } catch (error) {
    console.error("Error saving review:", error)
    return NextResponse.json({ error: "Failed to save review" }, { status: 500 })
  }
}

export async function GET() {
  try {
    // Try to get reviews from Supabase
    let reviews = []
    try {
      reviews = await fetchReviews()
    } catch (supabaseError) {
      // Don't log the error if it's about the missing table
      if (!(supabaseError instanceof Error && supabaseError.message.includes("does not exist"))) {
        console.error("Error fetching reviews from Supabase:", supabaseError)
      }
      // Continue with empty array if Supabase fails
    }

    // If no reviews from Supabase, get from local storage
    if (reviews.length === 0) {
      reviews = getReviews()
    }

    return NextResponse.json({ reviews })
  } catch (error) {
    console.error("Error fetching reviews:", error)
    return NextResponse.json({ error: "Failed to fetch reviews" }, { status: 500 })
  }
}

