import { NextResponse } from "next/server"
import { updateReviewStatus } from "@/lib/supabase-server"

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const { approved, moderated } = await request.json()
    const id = params.id

    if (!id) {
      return NextResponse.json({ error: "Review ID is required" }, { status: 400 })
    }

    // Исправляем вызов функции, убедившись, что все параметры передаются корректно
    const updated = await updateReviewStatus(id, approved, moderated)
    return NextResponse.json({ success: updated })
  } catch (error) {
    console.error("Error updating review status:", error)
    return NextResponse.json({ error: "Failed to update review status" }, { status: 500 })
  }
}

