import { NextResponse } from "next/server"

// Отключаем API-маршрут для отправки электронной почты
export async function POST(request: Request) {
  return NextResponse.json({ success: false, message: "Email notifications are disabled" }, { status: 200 })
}

