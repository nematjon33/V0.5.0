import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Phone, Mail, Clock } from "lucide-react"
import type { Metadata } from "next"
import AdminButton from "@/components/admin/admin-button"

export const metadata: Metadata = {
  title: "Контакты | Olucha-fresh - доставка свежих овощей, фруктов и сухофруктов",
  description: "Свяжитесь с нами для заказа свежих овощей, фруктов и сухофруктов с доставкой в Челябинске",
  keywords: "контакты, доставка фруктов, доставка овощей, Челябинск, Olucha-fresh",
}

export default function ContactsPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl md:text-4xl font-bold mb-8">Контакты</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div>
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Телефон</h3>
                <p className="text-muted-foreground">+7 904 817-97-62</p>
                <p className="text-muted-foreground mt-1">WhatsApp: +7 950 724-98-62</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Email</h3>
                <p className="text-muted-foreground">nematcon4@gmail.com</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Время работы</h3>
                <p className="text-muted-foreground">Пн-Пт: 9:00 - 20:00</p>
                <p className="text-muted-foreground">Сб-Вс: 10:00 - 18:00</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <MapPin className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Адрес</h3>
                <p className="text-muted-foreground">г. Челябинск, ул. Артиллерийская, 116/1</p>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <h2 className="text-xl font-bold mb-4">Информация о доставке</h2>
            <div className="space-y-4 text-muted-foreground">
              <p>Мы осуществляем доставку по всему городу в течение дня.</p>
              <p>Стоимость доставки: 300 ₽</p>
              <p className="font-medium text-primary">Бесплатная доставка при заказе от 2399 ₽</p>
              <p>Время доставки согласовывается с менеджером после оформления заказа.</p>
            </div>
          </div>
        </div>

        <div>
          <div className="border rounded-lg p-6 shadow-sm">
            <h2 className="text-xl font-bold mb-6">Связаться с нами</h2>
            <form className="space-y-4">
              <div>
                <Label htmlFor="name">Имя</Label>
                <Input id="name" />
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" />
              </div>

              <div>
                <Label htmlFor="phone">Телефон</Label>
                <Input id="phone" type="tel" />
              </div>

              <div>
                <Label htmlFor="message">Сообщение</Label>
                <Textarea id="message" rows={5} />
              </div>

              <Button type="submit" className="w-full">
                Отправить
              </Button>
            </form>
          </div>

          <div className="mt-8 rounded-lg overflow-hidden shadow-sm h-[400px]">
            <div
              dangerouslySetInnerHTML={{
                __html: `<script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Aa64bb80edf7a7a1fee0f108b4abf8f9e56bece76eb66f125407a7c9195512221&amp;width=100%&amp;height=400&amp;lang=ru_RU&amp;scroll=true"></script>`,
              }}
            />
          </div>
        </div>
      </div>

      {/* Панель управления */}
      <div className="mt-16 text-center">
        <AdminButton />
      </div>
    </div>
  )
}

