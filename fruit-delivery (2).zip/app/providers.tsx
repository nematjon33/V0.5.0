"use client"

import type React from "react"

import { CartProvider } from "@/hooks/use-cart"
import { ProductsProvider } from "@/hooks/use-products"
import { AuthProvider } from "@/hooks/use-auth"
import { BonusCardProvider } from "@/hooks/use-bonus-card"
import { OrdersProvider } from "@/hooks/use-orders"
import { ReviewsProvider } from "@/hooks/use-reviews"

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <BonusCardProvider>
        <OrdersProvider>
          <ReviewsProvider>
            <ProductsProvider>
              <CartProvider>{children}</CartProvider>
            </ProductsProvider>
          </ReviewsProvider>
        </OrdersProvider>
      </BonusCardProvider>
    </AuthProvider>
  )
}

