import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Truck, Phone, ShieldCheck } from "lucide-react"
import Stories from "@/components/stories"

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-primary/10 to-background py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 gradient-heading">
                Свежие овощи, фрукты и сухофрукты с доставкой
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Olucha-fresh доставляет только свежие и качественные продукты прямо к вашей двери в течение дня по
                Челябинску
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="font-medium">
                  <Link href="/catalog">
                    Перейти в каталог
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/contacts">Связаться с нами</Link>
                </Button>
              </div>
            </div>
            <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden shadow-lg">
              <Image
                src="https://images.unsplash.com/photo-1610832958506-aa56368176cf?q=80&w=1000&auto=format&fit=crop"
                alt="Свежие фрукты и овощи"
                fill
                className="object-cover"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-r from-primary/30 to-transparent mix-blend-overlay" />
            </div>
          </div>
        </div>
      </section>

      {/* Stories Section */}
      <section className="py-4 bg-muted/20">
        <div className="container mx-auto px-4">
          <Stories />
        </div>
      </section>

      {/* Features */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12 gradient-heading">Почему выбирают нас</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 rounded-lg border shadow-sm hover:shadow-md transition-shadow card-hover">
              <div className="bg-primary/10 p-3 rounded-full mb-4">
                <Truck className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Быстрая доставка</h3>
              <p className="text-muted-foreground">Доставляем заказы в течение дня по всему Челябинску</p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-lg border shadow-sm hover:shadow-md transition-shadow card-hover">
              <div className="bg-primary/10 p-3 rounded-full mb-4">
                <ShieldCheck className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Свежие продукты</h3>
              <p className="text-muted-foreground">Мы отбираем только самые свежие и качественные продукты</p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-lg border shadow-sm hover:shadow-md transition-shadow card-hover">
              <div className="bg-primary/10 p-3 rounded-full mb-4">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Поддержка клиентов</h3>
              <p className="text-muted-foreground">Наши менеджеры всегда на связи и готовы помочь</p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">Наши категории</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Link href="/catalog?tab=fruits" className="group">
              <div className="relative h-64 rounded-lg overflow-hidden shadow-md">
                <Image
                  src="https://images.unsplash.com/photo-1619566636858-adf3ef46400b?q=80&w=500&auto=format&fit=crop"
                  alt="Фрукты"
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <h3 className="text-white text-2xl font-bold">Фрукты</h3>
                </div>
              </div>
            </Link>
            <Link href="/catalog?tab=vegetables" className="group">
              <div className="relative h-64 rounded-lg overflow-hidden shadow-md">
                <Image
                  src="https://images.unsplash.com/photo-1566385101042-1a0aa0c1268c?q=80&w=500&auto=format&fit=crop"
                  alt="Овощи"
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <h3 className="text-white text-2xl font-bold">Овощи</h3>
                </div>
              </div>
            </Link>
            <Link href="/catalog?tab=dryFruits" className="group">
              <div className="relative h-64 rounded-lg overflow-hidden shadow-md">
                <Image
                  src="https://images.unsplash.com/photo-1596591868231-05e882e38a8f?q=80&w=500&auto=format&fit=crop"
                  alt="Сухофрукты"
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <h3 className="text-white text-2xl font-bold">Сухофрукты</h3>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Delivery Info */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="bg-primary/5 rounded-lg p-8 shadow-sm">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/2">
                <h2 className="text-2xl md:text-3xl font-bold mb-4">Доставка по Челябинску</h2>
                <p className="text-muted-foreground mb-4">
                  Мы доставляем свежие овощи, фрукты и сухофрукты по всему Челябинску и ближайшим пригородам.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary"></div>
                    <span>Стоимость доставки: 300 ₽</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary"></div>
                    <span className="font-medium">Бесплатная доставка при заказе от 2399 ₽</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary"></div>
                    <span>Доставка в день заказа или на следующий день</span>
                  </li>
                </ul>
                <Button asChild className="mt-6">
                  <Link href="/delivery">Подробнее о доставке</Link>
                </Button>
              </div>
              <div className="md:w-1/2">
                <div className="relative h-64 rounded-lg overflow-hidden shadow-md">
                  <Image
                    src="https://images.unsplash.com/photo-1616401784845-180882ba9ba8?q=80&w=500&auto=format&fit=crop"
                    alt="Доставка"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary/10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Готовы сделать заказ?</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Выбирайте из широкого ассортимента свежих овощей, фруктов и сухофруктов и получайте их с доставкой на дом
          </p>
          <Button asChild size="lg" className="font-medium">
            <Link href="/catalog">Сделать заказ</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}

