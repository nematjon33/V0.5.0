import { Truck, Clock, CreditCard, CheckCircle } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Доставка | Olucha-fresh - доставка свежих овощей, фруктов и сухофруктов",
  description: "Условия доставки свежих овощей, фруктов и сухофруктов в Челябинске. Бесплатная доставка от 2399₽",
  keywords: "доставка фруктов, доставка овощей, Челябинск, бесплатная доставка, Olucha-fresh",
}

export default function DeliveryPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl md:text-4xl font-bold mb-8">Информация о доставке</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div>
          <h2 className="text-2xl font-bold mb-6">Условия доставки</h2>

          <div className="space-y-8">
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Truck className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Зона доставки</h3>
                <p className="text-muted-foreground">
                  Мы осуществляем доставку по всему Челябинску и ближайшим пригородам.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Время доставки</h3>
                <p className="text-muted-foreground">
                  Доставка осуществляется в день заказа или на следующий день, в зависимости от времени оформления
                  заказа и загруженности курьеров.
                </p>
                <p className="text-muted-foreground mt-2">
                  Точное время доставки согласовывается с менеджером после оформления заказа.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <CreditCard className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Стоимость доставки</h3>
                <p className="text-muted-foreground">Стоимость доставки: 300 ₽</p>
                <p className="text-primary font-medium mt-2">Бесплатная доставка при заказе от 2399 ₽</p>
              </div>
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-6">Как это работает</h2>

          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-4 rounded-full flex-shrink-0">
                <span className="font-bold">1</span>
              </div>
              <div>
                <h3 className="font-medium text-lg">Выберите товары</h3>
                <p className="text-muted-foreground">Добавьте нужные товары в корзину из нашего каталога.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-4 rounded-full flex-shrink-0">
                <span className="font-bold">2</span>
              </div>
              <div>
                <h3 className="font-medium text-lg">Оформите заказ</h3>
                <p className="text-muted-foreground">
                  Заполните форму заказа, указав контактные данные и адрес доставки.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-4 rounded-full flex-shrink-0">
                <span className="font-bold">3</span>
              </div>
              <div>
                <h3 className="font-medium text-lg">Подтверждение заказа</h3>
                <p className="text-muted-foreground">
                  Наш менеджер свяжется с вами для подтверждения заказа и уточнения деталей доставки.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-4 rounded-full flex-shrink-0">
                <span className="font-bold">4</span>
              </div>
              <div>
                <h3 className="font-medium text-lg">Получение заказа</h3>
                <p className="text-muted-foreground">
                  Курьер доставит ваш заказ по указанному адресу в согласованное время.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-8 p-6 border rounded-lg bg-muted/30 shadow-sm">
            <div className="flex items-start gap-4">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-medium text-lg">Гарантия свежести</h3>
                <p className="text-muted-foreground">
                  Мы гарантируем свежесть всех доставляемых продуктов. Если качество товара вас не устроит, мы заменим
                  его или вернем деньги.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

