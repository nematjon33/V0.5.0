"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useBonusCard } from "@/hooks/use-bonus-card"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight, Gift, Percent, Calendar, CreditCard, ShoppingBag } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export default function BonusPage() {
  const { bonusCard } = useBonusCard()
  const { isAuthenticated, user } = useAuth()

  // Расчет прогресса для следующего уровня скидки
  const calculateNextDiscountProgress = () => {
    if (!bonusCard) return { progress: 0, nextLevel: 1000, remaining: 1000 }

    const currentDiscount = bonusCard.discountPercent

    if (currentDiscount >= 7) {
      return { progress: 100, nextLevel: 0, remaining: 0 }
    }

    const nextDiscountLevel = (currentDiscount + 1) * 1000
    const lastOrderAmount = bonusCard.lastOrderAmount

    // Если последний заказ меньше следующего уровня скидки
    if (lastOrderAmount < nextDiscountLevel) {
      const progress = (lastOrderAmount / nextDiscountLevel) * 100
      const remaining = nextDiscountLevel - lastOrderAmount
      return { progress, nextLevel: nextDiscountLevel, remaining }
    }

    return { progress: 100, nextLevel: nextDiscountLevel, remaining: 0 }
  }

  const { progress, nextLevel, remaining } = calculateNextDiscountProgress()

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 animate-text-gradient bg-gradient-to-r from-primary via-green-500 to-primary bg-[length:200%_auto] bg-clip-text text-transparent">
        Бонусная программа
      </h1>

      {isAuthenticated ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gift className="h-5 w-5 text-primary" />
                  Ваша бонусная карта
                </CardTitle>
                <CardDescription>Накапливайте скидки с каждой покупкой</CardDescription>
              </CardHeader>
              <CardContent>
                {bonusCard ? (
                  <div className="space-y-6">
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Имя</p>
                        <p className="font-medium">{user?.name}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Телефон</p>
                        <p className="font-medium">{user?.phone}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Текущая скидка</p>
                        <p className="font-bold text-primary text-xl">{bonusCard.discountPercent}%</p>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-muted-foreground">Прогресс до следующего уровня</span>
                        <span className="text-sm font-medium">
                          {bonusCard.discountPercent < 7 ? `${bonusCard.discountPercent + 1}%` : "Максимальный уровень"}
                        </span>
                      </div>
                      <Progress value={progress} className="h-2" />

                      {bonusCard.discountPercent < 7 && (
                        <p className="text-xs text-muted-foreground mt-2">
                          Для получения скидки {bonusCard.discountPercent + 1}% сделайте заказ на сумму от {nextLevel} ₽
                          {remaining > 0 && ` (осталось ${remaining} ₽)`}
                        </p>
                      )}
                    </div>

                    <div className="pt-4 border-t">
                      <div className="flex justify-between mb-2">
                        <span className="text-muted-foreground">Всего потрачено</span>
                        <span className="font-medium">{bonusCard.totalSpent} ₽</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Последний заказ</span>
                        <span className="font-medium">{bonusCard.lastOrderAmount} ₽</span>
                      </div>
                    </div>

                    <div className="flex justify-center pt-4">
                      <Button asChild>
                        <Link href="/catalog">
                          Перейти в каталог
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <ShoppingBag className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">У вас пока нет бонусной карты</h3>
                    <p className="text-muted-foreground mb-6">Сделайте первый заказ, чтобы получить бонусную карту</p>
                    <Button asChild>
                      <Link href="/catalog">
                        Перейти в каталог
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Percent className="h-5 w-5 text-primary" />
                  Как это работает
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-3">
                  <div className="bg-primary/10 p-2 rounded-full h-8 w-8 flex items-center justify-center flex-shrink-0">
                    <ShoppingBag className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Делайте покупки</p>
                    <p className="text-sm text-muted-foreground">Размер скидки зависит от суммы вашего заказа</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="bg-primary/10 p-2 rounded-full h-8 w-8 flex items-center justify-center flex-shrink-0">
                    <Percent className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Получайте скидки</p>
                    <p className="text-sm text-muted-foreground">От 1% до 7% в зависимости от суммы заказа</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="bg-primary/10 p-2 rounded-full h-8 w-8 flex items-center justify-center flex-shrink-0">
                    <Calendar className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Ежемесячное обновление</p>
                    <p className="text-sm text-muted-foreground">Скидка обновляется в начале каждого месяца</p>
                  </div>
                </div>

                <div className="pt-4 border-t mt-4">
                  <p className="font-medium mb-2">Размер скидки:</p>
                  <ul className="space-y-1 text-sm">
                    <li className="flex justify-between">
                      <span>Заказ от 1000 ₽</span>
                      <span className="font-medium">1%</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Заказ от 2000 ₽</span>
                      <span className="font-medium">2%</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Заказ от 3000 ₽</span>
                      <span className="font-medium">3%</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Заказ от 4000 ₽</span>
                      <span className="font-medium">4%</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Заказ от 5000 ₽</span>
                      <span className="font-medium">5%</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Заказ от 6000 ₽</span>
                      <span className="font-medium">6%</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Заказ от 7000 ₽</span>
                      <span className="font-medium">7%</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      ) : (
        <div className="text-center py-12">
          <CreditCard className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-xl font-bold mb-2">Войдите в аккаунт</h2>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Для доступа к бонусной программе необходимо войти в аккаунт или зарегистрироваться
          </p>
          <div className="flex justify-center gap-4">
            <Button asChild variant="outline">
              <Link href="/auth/register">Регистрация</Link>
            </Button>
            <Button asChild>
              <Link href="/auth/login">
                Войти
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

