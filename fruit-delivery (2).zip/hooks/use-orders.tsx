"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import type { Order } from "@/lib/types"
import { useAuth } from "@/hooks/use-auth"
import { useBonusCard } from "@/hooks/use-bonus-card"
import {
  getOrders,
  addOrder as addOrderToStorage,
  updateOrderStatus as updateOrderStatusInStorage,
} from "@/lib/local-storage"
import { sendOrderNotification, sendStatusUpdateNotification } from "@/lib/telegram"

interface OrdersContextType {
  orders: Order[]
  addOrder: (orderData: Omit<Order, "id" | "date" | "userId" | "status" | "statusHistory">) => Promise<Order>
  getOrderById: (id: string) => Order | undefined
  getUserOrders: () => Order[]
  getAllOrders: () => Order[]
  updateOrderStatus: (id: string, status: Order["status"]) => Promise<void>
  loading: boolean
  error: string | null
  refreshOrders: () => Promise<void>
}

const OrdersContext = createContext<OrdersContextType>({
  orders: [],
  addOrder: async () => ({}) as Order,
  getOrderById: () => undefined,
  getUserOrders: () => [],
  getAllOrders: () => [],
  updateOrderStatus: async () => {},
  loading: false,
  error: null,
  refreshOrders: async () => {},
})

export function OrdersProvider({ children }: { children: React.ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { user } = useAuth()
  const { updateBonusCard } = useBonusCard()

  // Загрузка заказов при инициализации
  useEffect(() => {
    refreshOrders()
  }, [])

  // Функция для обновления списка заказов
  const refreshOrders = async () => {
    setLoading(true)
    setError(null)

    try {
      // Загружаем заказы из локального хранилища
      const storedOrders = getOrders()
      setOrders(storedOrders)
    } catch (error) {
      console.error("Ошибка при загрузке заказов:", error)
      setError("Не удалось загрузить заказы. Пожалуйста, попробуйте позже.")
    } finally {
      setLoading(false)
    }
  }

  // Обновляем функцию addOrder, чтобы удалить отправку email
  const addOrder = async (
    orderData: Omit<Order, "id" | "date" | "userId" | "status" | "statusHistory">,
  ): Promise<Order> => {
    if (!user) {
      throw new Error("Пользователь не авторизован")
    }

    setLoading(true)
    setError(null)

    try {
      const now = new Date().toISOString()
      const orderId = `order-${Date.now()}`

      const newOrder: Order = {
        ...orderData,
        id: orderId,
        date: now,
        userId: user.id,
        status: "created",
        statusHistory: [{ status: "created", timestamp: now }],
      }

      // Сохраняем заказ в локальное хранилище
      addOrderToStorage(newOrder)

      // Обновляем состояние
      setOrders((prev) => [newOrder, ...prev])

      // Отправляем уведомление в Telegram
      try {
        await sendOrderNotification(newOrder)
      } catch (telegramError) {
        console.error("Ошибка при отправке уведомления в Telegram:", telegramError)
      }

      // Обновляем бонусную карту пользователя
      try {
        await updateBonusCard(newOrder.finalPrice)
      } catch (bonusError) {
        console.error("Ошибка при обновлении бонусной карты:", bonusError)
      }

      return newOrder
    } catch (error) {
      console.error("Ошибка при добавлении заказа:", error)
      setError("Не удалось оформить заказ. Пожалуйста, попробуйте позже.")
      throw error
    } finally {
      setLoading(false)
    }
  }

  // Получение заказа по ID
  const getOrderById = (id: string): Order | undefined => {
    return orders.find((order) => order.id === id)
  }

  // Получение заказов текущего пользователя
  const getUserOrders = (): Order[] => {
    if (!user) return []
    return orders.filter((order) => order.userId === user.id)
  }

  // Получение всех заказов (для админа)
  const getAllOrders = (): Order[] => {
    return [...orders].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  }

  // Обновление статуса заказа
  const updateOrderStatus = async (id: string, status: Order["status"]) => {
    setLoading(true)
    setError(null)

    try {
      const orderToUpdate = orders.find((order) => order.id === id)

      if (!orderToUpdate) {
        throw new Error("Заказ не найден")
      }

      const now = new Date().toISOString()
      const newStatusHistory = [...orderToUpdate.statusHistory, { status, timestamp: now }]

      // Обновляем статус заказа в локальном хранилище
      updateOrderStatusInStorage(id, status, newStatusHistory)

      // Обновляем состояние
      setOrders((prev) => {
        const updatedOrders = prev.map((order) => {
          if (order.id === id) {
            return {
              ...order,
              status,
              statusHistory: newStatusHistory,
            }
          }
          return order
        })
        return updatedOrders
      })

      // Отправляем уведомление в Telegram об изменении статуса
      try {
        await sendStatusUpdateNotification(orderToUpdate, status)
      } catch (telegramError) {
        console.error("Ошибка при отправке уведомления в Telegram:", telegramError)
      }
    } catch (error) {
      console.error("Ошибка при обновлении статуса заказа:", error)
      setError("Не удалось обновить статус заказа. Пожалуйста, попробуйте позже.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <OrdersContext.Provider
      value={{
        orders,
        addOrder,
        getOrderById,
        getUserOrders,
        getAllOrders,
        updateOrderStatus,
        loading,
        error,
        refreshOrders,
      }}
    >
      {children}
    </OrdersContext.Provider>
  )
}

export function useOrders() {
  return useContext(OrdersContext)
}

