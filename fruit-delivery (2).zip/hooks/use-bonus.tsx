"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import type { BonusInfo } from "@/lib/types"
import { useAuth } from "@/hooks/use-auth"

interface BonusContextType {
  bonusInfo: BonusInfo | null
  allBonusInfo: BonusInfo[]
  calculateDiscount: (amount: number) => number
  updateBonusInfo: (orderAmount: number) => void
  loading: boolean
}

const BonusContext = createContext<BonusContextType>({
  bonusInfo: null,
  allBonusInfo: [],
  calculateDiscount: () => 0,
  updateBonusInfo: () => {},
  loading: false,
})

export function BonusProvider({ children }: { children: React.ReactNode }) {
  const [bonusInfo, setBonusInfo] = useState<BonusInfo | null>(null)
  const [allBonusInfo, setAllBonusInfo] = useState<BonusInfo[]>([])
  const [loading, setLoading] = useState(true)
  const { user, isAuthenticated } = useAuth()

  // Загрузка информации о бонусах при инициализации или смене пользователя
  useEffect(() => {
    if (isAuthenticated && user) {
      loadBonusInfo()
    } else {
      setBonusInfo(null)
    }
  }, [isAuthenticated, user])

  // Загрузка всех бонусов для админ-панели
  useEffect(() => {
    loadAllBonusInfo()
  }, [])

  // Проверка и сброс бонусов в начале месяца
  useEffect(() => {
    checkMonthlyReset()
  }, [bonusInfo])

  const loadBonusInfo = () => {
    setLoading(true)
    try {
      if (!user) {
        setBonusInfo(null)
        return
      }

      const bonusKey = `bonus-${user.id}`
      const savedBonusJson = localStorage.getItem(bonusKey)

      if (savedBonusJson) {
        const savedBonus = JSON.parse(savedBonusJson)
        setBonusInfo(savedBonus)
      } else {
        // Создаем новую запись о бонусах для пользователя
        const newBonusInfo: BonusInfo = {
          userId: user.id,
          userName: user.name,
          userPhone: user.phone,
          lastOrderAmount: 0,
          discountPercent: 0,
          lastOrderDate: new Date().toISOString(),
          nextResetDate: getNextMonthFirstDay().toISOString(),
        }

        setBonusInfo(newBonusInfo)
        localStorage.setItem(bonusKey, JSON.stringify(newBonusInfo))
      }
    } catch (error) {
      console.error("Ошибка при загрузке информации о бонусах:", error)
    } finally {
      setLoading(false)
    }
  }

  const loadAllBonusInfo = () => {
    try {
      const allBonuses: BonusInfo[] = []

      // Получаем все ключи из localStorage
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i)

        if (key && key.startsWith("bonus-")) {
          try {
            const bonusData = JSON.parse(localStorage.getItem(key) || "")
            allBonuses.push(bonusData)
          } catch (e) {
            console.error(`Ошибка при парсинге бонуса: ${key}`, e)
          }
        }
      }

      setAllBonusInfo(allBonuses)
    } catch (error) {
      console.error("Ошибка при загрузке всех бонусов:", error)
    }
  }

  // Получение первого дня следующего месяца
  const getNextMonthFirstDay = () => {
    const now = new Date()
    return new Date(now.getFullYear(), now.getMonth() + 1, 1)
  }

  // Проверка необходимости сброса бонусов в начале месяца
  const checkMonthlyReset = () => {
    if (!bonusInfo) return

    const now = new Date()
    const resetDate = new Date(bonusInfo.nextResetDate)

    if (now >= resetDate) {
      // Сбрасываем бонусы в начале нового месяца
      const updatedBonusInfo = {
        ...bonusInfo,
        discountPercent: 0,
        nextResetDate: getNextMonthFirstDay().toISOString(),
      }

      setBonusInfo(updatedBonusInfo)

      if (user) {
        const bonusKey = `bonus-${user.id}`
        localStorage.setItem(bonusKey, JSON.stringify(updatedBonusInfo))
      }
    }
  }

  // Расчет скидки на основе предыдущего заказа
  const calculateDiscount = (amount: number): number => {
    if (!bonusInfo || bonusInfo.discountPercent === 0) return 0

    // Рассчитываем скидку в процентах от суммы заказа
    const discountAmount = Math.round(amount * (bonusInfo.discountPercent / 100))
    return discountAmount
  }

  // Обновление информации о бонусах после нового заказа
  const updateBonusInfo = (orderAmount: number) => {
    if (!user) return

    // Определяем процент скидки для следующего заказа
    let newDiscountPercent = 0

    if (orderAmount >= 7000) {
      newDiscountPercent = 7 // Максимальная скидка 7%
    } else if (orderAmount >= 1000) {
      // Округляем до целого числа, но не более 7%
      newDiscountPercent = Math.min(Math.floor(orderAmount / 1000), 7)
    }

    const updatedBonusInfo: BonusInfo = {
      userId: user.id,
      userName: user.name,
      userPhone: user.phone,
      lastOrderAmount: orderAmount,
      discountPercent: newDiscountPercent,
      lastOrderDate: new Date().toISOString(),
      nextResetDate: getNextMonthFirstDay().toISOString(),
    }

    setBonusInfo(updatedBonusInfo)

    // Сохраняем в localStorage
    const bonusKey = `bonus-${user.id}`
    localStorage.setItem(bonusKey, JSON.stringify(updatedBonusInfo))

    // Обновляем список всех бонусов
    loadAllBonusInfo()
  }

  return (
    <BonusContext.Provider
      value={{
        bonusInfo,
        allBonusInfo,
        calculateDiscount,
        updateBonusInfo,
        loading,
      }}
    >
      {children}
    </BonusContext.Provider>
  )
}

export function useBonus() {
  return useContext(BonusContext)
}

