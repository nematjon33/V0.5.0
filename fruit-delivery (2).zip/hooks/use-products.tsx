"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import type { Product } from "@/lib/types"
import { products as initialProducts } from "@/lib/products"
import {
  getProducts,
  addProduct as addProductToStorage,
  updateProduct as updateProductInStorage,
  deleteProduct as deleteProductFromStorage,
} from "@/lib/local-storage"

interface ProductsContextType {
  products: Product[]
  setProducts: (products: Product[]) => void
  addProduct: (product: Product) => Promise<void>
  updateProduct: (product: Product) => Promise<void>
  deleteProduct: (id: string) => Promise<void>
  loading: boolean
  refreshProducts: () => Promise<void>
  error: string | null
}

const ProductsContext = createContext<ProductsContextType>({
  products: [],
  setProducts: () => {},
  addProduct: async () => {},
  updateProduct: async () => {},
  deleteProduct: async () => {},
  loading: false,
  refreshProducts: async () => {},
  error: null,
})

export function ProductsProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [initialized, setInitialized] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Загрузка товаров при инициализации
  useEffect(() => {
    if (!initialized) {
      refreshProducts()
      setInitialized(true)
    }
  }, [initialized])

  // Функция для обновления списка товаров
  const refreshProducts = async () => {
    setLoading(true)
    setError(null)

    try {
      // Загружаем товары из локального хранилища
      const storedProducts = getProducts()

      // Сортируем товары по алфавиту
      const sortedProducts = [...storedProducts].sort((a, b) => a.name.localeCompare(b.name))

      setProducts(sortedProducts)
    } catch (error) {
      console.error("Ошибка при обновлении товаров:", error)
      setError("Не удалось загрузить товары. Пожалуйста, попробуйте позже.")

      // В случае ошибки используем начальные данные
      setProducts([...initialProducts].sort((a, b) => a.name.localeCompare(b.name)))
    } finally {
      setLoading(false)
    }
  }

  // Добавление нового товара
  const addProduct = async (product: Product) => {
    try {
      setLoading(true)

      // Добавляем товар в локальное хранилище
      addProductToStorage(product)

      // Обновляем состояние
      setProducts((prevProducts) => {
        const newProducts = [...prevProducts, product].sort((a, b) => a.name.localeCompare(b.name))
        return newProducts
      })
    } catch (error) {
      console.error("Ошибка при добавлении товара:", error)
      setError("Не удалось добавить товар. Пожалуйста, попробуйте позже.")
    } finally {
      setLoading(false)
    }
  }

  // Обновление существующего товара
  const updateProduct = async (product: Product) => {
    try {
      setLoading(true)

      // Обновляем товар в локальном хранилище
      updateProductInStorage(product)

      // Обновляем состояние
      setProducts((prevProducts) => {
        const newProducts = prevProducts
          .map((p) => (p.id === product.id ? product : p))
          .sort((a, b) => a.name.localeCompare(b.name))

        return newProducts
      })
    } catch (error) {
      console.error("Ошибка при обновлении товара:", error)
      setError("Не удалось обновить товар. Пожалуйста, попробуйте позже.")
    } finally {
      setLoading(false)
    }
  }

  // Удаление товара
  const deleteProduct = async (id: string) => {
    try {
      setLoading(true)

      // Удаляем товар из локального хранилища
      deleteProductFromStorage(id)

      // Обновляем состояние
      setProducts((prevProducts) => {
        const newProducts = prevProducts.filter((p) => p.id !== id)
        return newProducts
      })
    } catch (error) {
      console.error("Ошибка при удалении товара:", error)
      setError("Не удалось удалить товар. Пожалуйста, попробуйте позже.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <ProductsContext.Provider
      value={{
        products,
        setProducts,
        addProduct,
        updateProduct,
        deleteProduct,
        loading,
        refreshProducts,
        error,
      }}
    >
      {children}
    </ProductsContext.Provider>
  )
}

export function useProducts() {
  return useContext(ProductsContext)
}

