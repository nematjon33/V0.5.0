"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import type { BonusCard } from "@/lib/types"
import { useAuth } from "@/hooks/use-auth"

interface BonusCardContextType {
  bonusCard: BonusCard | null
  updateBonusCard: (orderAmount: number) => Promise<BonusCard | null>
  getAllBonusCards: () => BonusCard[]
  resetBonusCards: () => void
}

const BonusCardContext = createContext<BonusCardContextType>({
  bonusCard: null,
  updateBonusCard: async () => null,
  getAllBonusCards: () => [],
  resetBonusCards: () => {},
})

export function BonusCardProvider({ children }: { children: React.ReactNode }) {
  const [bonusCard, setBonusCard] = useState<BonusCard | null>(null)
  const [allBonusCards, setAllBonusCards] = useState<BonusCard[]>([])
  const { user } = useAuth()

  // Загрузка бонусных карт из localStorage при инициализации
  useEffect(() => {
    const storedCards = localStorage.getItem("bonus-cards")
    if (storedCards) {
      try {
        const parsedCards = JSON.parse(storedCards)
        if (Array.isArray(parsedCards)) {
          setAllBonusCards(parsedCards)

          // Если пользователь авторизован, находим его карту
          if (user) {
            const userCard = parsedCards.find((card) => card.userId === user.id)
            if (userCard) {
              setBonusCard(userCard)
            }
          }
        }
      } catch (error) {
        console.error("Ошибка при загрузке бонусных карт из localStorage:", error)
      }
    }

    // Проверяем, нужно ли сбросить скидки (новый месяц)
    checkMonthlyReset()
  }, [user])

  // Сохранение бонусных карт в localStorage при изменении
  useEffect(() => {
    if (allBonusCards.length > 0) {
      localStorage.setItem("bonus-cards", JSON.stringify(allBonusCards))
    }
  }, [allBonusCards])

  // Проверка необходимости ежемесячного сброса скидок
  const checkMonthlyReset = () => {
    const lastResetDate = localStorage.getItem("last-bonus-reset")
    const currentDate = new Date()
    const currentMonth = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}`

    if (lastResetDate !== currentMonth) {
      // Сбрасываем скидки в начале нового месяца
      resetBonusCards()
      localStorage.setItem("last-bonus-reset", currentMonth)
    }
  }

  // Обновление бонусной карты пользователя
  const updateBonusCard = async (orderAmount: number): Promise<BonusCard | null> => {
    if (!user) return null

    // Находим существующую карту или создаем новую
    const existingCardIndex = allBonusCards.findIndex((card) => card.userId === user.id)
    const existingCard = existingCardIndex >= 0 ? allBonusCards[existingCardIndex] : null

    // Рассчитываем новую скидку на основе суммы последнего заказа
    // Скидка будет применяться к следующему заказу
    const newDiscountPercent = calculateDiscountPercent(orderAmount)

    const updatedCard: BonusCard = {
      userId: user.id,
      discountPercent: newDiscountPercent,
      totalSpent: (existingCard?.totalSpent || 0) + orderAmount,
      lastOrderDate: new Date().toISOString(),
      lastOrderAmount: orderAmount,
    }

    // Обновляем список всех карт
    if (existingCardIndex >= 0) {
      const updatedCards = [...allBonusCards]
      updatedCards[existingCardIndex] = updatedCard
      setAllBonusCards(updatedCards)
    } else {
      setAllBonusCards((prev) => [...prev, updatedCard])
    }

    // Обновляем карту текущего пользователя
    setBonusCard(updatedCard)

    return updatedCard
  }

  // Расчет процента скидки на основе суммы заказа
  const calculateDiscountPercent = (orderAmount: number): number => {
    if (orderAmount >= 7000) return 7
    if (orderAmount >= 6000) return 6
    if (orderAmount >= 5000) return 5
    if (orderAmount >= 4000) return 4
    if (orderAmount >= 3000) return 3
    if (orderAmount >= 2000) return 2
    if (orderAmount >= 1000) return 1
    return 0
  }

  // Получение всех бонусных карт
  const getAllBonusCards = (): BonusCard[] => {
    return allBonusCards
  }

  // Сброс всех бонусных карт (в начале месяца)
  const resetBonusCards = () => {
    const resetCards = allBonusCards.map((card) => ({
      ...card,
      discountPercent: 0,
    }))

    setAllBonusCards(resetCards)

    if (bonusCard) {
      setBonusCard({
        ...bonusCard,
        discountPercent: 0,
      })
    }
  }

  return (
    <BonusCardContext.Provider
      value={{
        bonusCard,
        updateBonusCard,
        getAllBonusCards,
        resetBonusCards,
      }}
    >
      {children}
    </BonusCardContext.Provider>
  )
}

export function useBonusCard() {
  return useContext(BonusCardContext)
}

