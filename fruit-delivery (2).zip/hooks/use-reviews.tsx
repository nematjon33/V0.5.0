"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import type { Review } from "@/lib/types"
import { useAuth } from "@/hooks/use-auth"
import { v4 as uuidv4 } from "uuid"

// Импортируем функции из клиентского файла Supabase
import {
  fetchReviews,
  saveReview as saveReviewToAPI,
  updateReviewStatus as updateReviewStatusToAPI,
} from "@/lib/supabase-client"

interface ReviewsContextType {
  reviews: Review[]
  addReview: (
    reviewData: Omit<Review, "id" | "date" | "userId" | "userName" | "approved" | "moderated">,
  ) => Promise<Review>
  getUserReviews: () => Review[]
  getProductReviews: (productId: string) => Review[]
  getApprovedReviews: () => Review[]
  getPendingReviews: () => Review[]
  approveReview: (id: string) => void
  rejectReview: (id: string) => void
  loading: boolean
}

const ReviewsContext = createContext<ReviewsContextType>({
  reviews: [],
  addReview: async () => ({}) as Review,
  getUserReviews: () => [],
  getProductReviews: () => [],
  getApprovedReviews: () => [],
  getPendingReviews: () => [],
  approveReview: () => {},
  rejectReview: () => {},
  loading: false,
})

export function ReviewsProvider({ children }: { children: React.ReactNode }) {
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()

  // Загрузка отзывов при инициализации
  useEffect(() => {
    const loadReviews = async () => {
      try {
        setLoading(true)

        // Try to fetch reviews from Supabase
        let fetchedReviews: Review[] = []
        try {
          fetchedReviews = await fetchReviews()
        } catch (error) {
          // Don't log the error if it's about the missing table
          if (!(error instanceof Error && error.message.includes("does not exist"))) {
            console.error("Error fetching reviews from Supabase:", error)
          }
          // Continue with empty array if Supabase fails
        }

        // Get reviews from local storage as fallback
        const storedReviews = getReviews()

        // Combine reviews from Supabase and local storage, removing duplicates
        const combinedReviews = [...fetchedReviews]

        // Add reviews from local storage that don't exist in Supabase
        storedReviews.forEach((localReview) => {
          if (!combinedReviews.some((review) => review.id === localReview.id)) {
            combinedReviews.push(localReview)
          }
        })

        setReviews(combinedReviews)
      } catch (error) {
        console.error("Error loading reviews:", error)
        // Fallback to local storage only
        try {
          const storedReviews = getReviews()
          setReviews(storedReviews)
        } catch (localError) {
          console.error("Error loading reviews from local storage:", localError)
          setReviews([])
        }
      } finally {
        setLoading(false)
      }
    }

    loadReviews()
  }, [])

  // Добавление нового отзыва
  const addReview = async (
    reviewData: Omit<Review, "id" | "date" | "userId" | "userName" | "approved" | "moderated">,
  ): Promise<Review> => {
    if (!user) {
      throw new Error("Пользователь не авторизован")
    }

    try {
      setLoading(true)

      const newReview: Review = {
        ...reviewData,
        id: uuidv4(),
        userId: user.id,
        userName: user.name,
        date: new Date().toISOString(),
        approved: false,
        moderated: false,
      }

      // Сохраняем отзыв через API
      await saveReviewToAPI(newReview)

      // Обновляем состояние
      setReviews((prev) => [newReview, ...prev])

      return newReview
    } catch (error) {
      console.error("Ошибка при добавлении отзыва:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  // Получение отзывов пользователя
  const getUserReviews = (): Review[] => {
    if (!user) return []
    return reviews.filter((review) => review.userId === user.id)
  }

  // Получение отзывов о товаре
  const getProductReviews = (productId: string): Review[] => {
    return reviews.filter((review) => review.productId === productId && review.approved)
  }

  // Получение одобренных отзывов
  const getApprovedReviews = (): Review[] => {
    return reviews.filter((review) => review.approved)
  }

  // Получение отзывов на модерации
  const getPendingReviews = (): Review[] => {
    return reviews.filter((review) => !review.moderated)
  }

  // Одобрение отзыва
  const approveReview = async (id: string) => {
    try {
      setLoading(true)
      // Обновляем статус отзыва через API
      const success = await updateReviewStatusToAPI(id, true, true)

      if (success) {
        // Обновляем состояние только если API-запрос был успешным
        setReviews((prev) =>
          prev.map((review) => (review.id === id ? { ...review, approved: true, moderated: true } : review)),
        )
      }
    } catch (error) {
      console.error("Ошибка при одобрении отзыва:", error)
    } finally {
      setLoading(false)
    }
  }

  // Отклонение отзыва
  const rejectReview = async (id: string) => {
    try {
      setLoading(true)
      // Обновляем статус отзыва через API
      const success = await updateReviewStatusToAPI(id, false, true)

      if (success) {
        // Обновляем состояние только если API-запрос был успешным
        setReviews((prev) =>
          prev.map((review) => (review.id === id ? { ...review, approved: false, moderated: true } : review)),
        )
      }
    } catch (error) {
      console.error("Ошибка при отклонении отзыва:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <ReviewsContext.Provider
      value={{
        reviews,
        addReview,
        getUserReviews,
        getProductReviews,
        getApprovedReviews,
        getPendingReviews,
        approveReview,
        rejectReview,
        loading,
      }}
    >
      {children}
    </ReviewsContext.Provider>
  )
}

export function useReviews() {
  return useContext(ReviewsContext)
}

// Function to get reviews from local storage
const getReviews = (): Review[] => {
  try {
    const storedReviews = localStorage.getItem("reviews")
    return storedReviews ? JSON.parse(storedReviews) : []
  } catch (error) {
    console.error("Error getting reviews from local storage:", error)
    return []
  }
}

