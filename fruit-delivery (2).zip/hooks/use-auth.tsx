"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"

interface User {
  id: string
  name: string
  phone: string
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  login: (user: User) => void
  register: (name: string, phone: string) => Promise<User>
  logout: () => void
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  login: () => {},
  register: async () => ({ id: "", name: "", phone: "" }),
  logout: () => {},
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [initialized, setInitialized] = useState(false)

  // Загрузка пользователя из localStorage при инициализации
  useEffect(() => {
    if (!initialized) {
      const storedUser = localStorage.getItem("user")
      if (storedUser) {
        try {
          const parsedUser = JSON.parse(storedUser)
          setUser(parsedUser)
          setIsAuthenticated(true)
        } catch (error) {
          console.error("Ошибка при загрузке пользователя из localStorage:", error)
          localStorage.removeItem("user")
        }
      }
      setInitialized(true)
    }
  }, [initialized])

  // Функция для входа пользователя
  const login = (userData: User) => {
    setUser(userData)
    setIsAuthenticated(true)
    localStorage.setItem("user", JSON.stringify(userData))
  }

  // Функция для регистрации пользователя
  const register = async (name: string, phone: string): Promise<User> => {
    // В реальном приложении здесь был бы запрос к API
    // Имитируем создание пользователя
    const newUser = {
      id: Date.now().toString(),
      name,
      phone,
    }

    login(newUser)
    return newUser
  }

  // Функция для выхода пользователя
  const logout = () => {
    setUser(null)
    setIsAuthenticated(false)
    localStorage.removeItem("user")
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}

