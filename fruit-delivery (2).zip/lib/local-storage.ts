import type { Product, Order, Review, DeliveryPricing } from "@/lib/types"
import { products as initialProducts } from "@/lib/products"

// Ключи для localStorage
const STORAGE_KEYS = {
  PRODUCTS: "olucha-products",
  ORDERS: "olucha-orders",
  REVIEWS: "olucha-reviews",
  CUSTOM_PRODUCTS: "olucha-custom-products",
  DELETED_PRODUCTS: "olucha-deleted-products",
  DELIVERY_PRICING: "olucha-delivery-pricing",
  DELIVERY_COEFFICIENT: "olucha-delivery-coefficient",
}

// Значения по умолчанию для настроек доставки
export const DEFAULT_DELIVERY_PRICING: DeliveryPricing[] = [
  { minOrderAmount: 0, maxOrderAmount: 1000, price: 350 },
  { minOrderAmount: 1001, maxOrderAmount: 1500, price: 250 },
  { minOrderAmount: 1501, maxOrderAmount: null, price: 0 },
]

export const DEFAULT_DELIVERY_COEFFICIENT = 1.0

// Функция для получения продуктов из localStorage
export function getProducts(): Product[] {
  try {
    // Сначала проверяем наличие всех продуктов в localStorage
    const storedProducts = localStorage.getItem(STORAGE_KEYS.PRODUCTS)
    if (storedProducts) {
      const parsedProducts = JSON.parse(storedProducts)
      if (Array.isArray(parsedProducts) && parsedProducts.length > 0) {
        return parsedProducts
      }
    }

    // Если в localStorage нет продуктов, используем начальные данные
    // и сохраняем их в localStorage
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(initialProducts))
    return initialProducts
  } catch (error) {
    console.error("Ошибка при получении продуктов из localStorage:", error)
    return initialProducts
  }
}

// Функция для сохранения продуктов в localStorage
export function saveProducts(products: Product[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products))
  } catch (error) {
    console.error("Ошибка при сохранении продуктов в localStorage:", error)
  }
}

// Функция для добавления продукта
export function addProduct(product: Product): Product {
  try {
    const products = getProducts()
    const updatedProducts = [...products, product]
    saveProducts(updatedProducts)
    return product
  } catch (error) {
    console.error("Ошибка при добавлении продукта:", error)
    return product
  }
}

// Функция для обновления продукта
export function updateProduct(product: Product): Product {
  try {
    const products = getProducts()
    const updatedProducts = products.map((p) => (p.id === product.id ? product : p))
    saveProducts(updatedProducts)
    return product
  } catch (error) {
    console.error("Ошибка при обновлении продукта:", error)
    return product
  }
}

// Функция для удаления продукта
export function deleteProduct(id: string): boolean {
  try {
    const products = getProducts()
    const updatedProducts = products.filter((p) => p.id !== id)
    saveProducts(updatedProducts)

    // Сохраняем ID удаленного продукта
    const deletedIds = getDeletedProductIds()
    if (!deletedIds.includes(id)) {
      localStorage.setItem(STORAGE_KEYS.DELETED_PRODUCTS, JSON.stringify([...deletedIds, id]))
    }

    return true
  } catch (error) {
    console.error("Ошибка при удалении продукта:", error)
    return false
  }
}

// Функция для получения ID удаленных продуктов
export function getDeletedProductIds(): string[] {
  try {
    const storedIds = localStorage.getItem(STORAGE_KEYS.DELETED_PRODUCTS)
    if (storedIds) {
      const parsedIds = JSON.parse(storedIds)
      if (Array.isArray(parsedIds)) {
        return parsedIds
      }
    }
    return []
  } catch (error) {
    console.error("Ошибка при получении ID удаленных продуктов:", error)
    return []
  }
}

// Функция для получения заказов из localStorage
export function getOrders(): Order[] {
  try {
    const storedOrders = localStorage.getItem(STORAGE_KEYS.ORDERS)
    if (storedOrders) {
      const parsedOrders = JSON.parse(storedOrders)
      if (Array.isArray(parsedOrders)) {
        return parsedOrders
      }
    }
    return []
  } catch (error) {
    console.error("Ошибка при получении заказов из localStorage:", error)
    return []
  }
}

// Функция для сохранения заказов в localStorage
export function saveOrders(orders: Order[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders))
  } catch (error) {
    console.error("Ошибка при сохранении заказов в localStorage:", error)
  }
}

// Функция для добавления заказа
export function addOrder(order: Order): Order {
  try {
    const orders = getOrders()
    const updatedOrders = [order, ...orders]
    saveOrders(updatedOrders)
    return order
  } catch (error) {
    console.error("Ошибка при добавлении заказа:", error)
    return order
  }
}

// Функция для обновления статуса заказа
export function updateOrderStatus(id: string, status: string, statusHistory: any[]): boolean {
  try {
    const orders = getOrders()
    const updatedOrders = orders.map((order) => {
      if (order.id === id) {
        return {
          ...order,
          status,
          statusHistory,
        }
      }
      return order
    })
    saveOrders(updatedOrders)
    return true
  } catch (error) {
    console.error("Ошибка при обновлении статуса заказа:", error)
    return false
  }
}

// Функция для получения отзывов из localStorage
export function getReviews(): Review[] {
  try {
    const storedReviews = localStorage.getItem(STORAGE_KEYS.REVIEWS)
    if (storedReviews) {
      const parsedReviews = JSON.parse(storedReviews)
      if (Array.isArray(parsedReviews)) {
        return parsedReviews
      }
    }
    return []
  } catch (error) {
    console.error("Ошибка при получении отзывов из localStorage:", error)
    return []
  }
}

// Функция для сохранения отзывов в localStorage
export function saveReviews(reviews: Review[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews))
  } catch (error) {
    console.error("Ошибка при сохранении отзывов в localStorage:", error)
  }
}

// Функция для добавления отзыва
export function addReview(review: Review): Review {
  try {
    const reviews = getReviews()
    const updatedReviews = [review, ...reviews]
    saveReviews(updatedReviews)

    // Обновляем статус заказа, чтобы отметить, что отзыв оставлен
    const orders = getOrders()
    const updatedOrders = orders.map((order) => {
      if (order.id === review.orderId) {
        return {
          ...order,
          reviewed: true,
        }
      }
      return order
    })
    saveOrders(updatedOrders)

    return review
  } catch (error) {
    console.error("Ошибка при добавлении отзыва:", error)
    return review
  }
}

// Функция для обновления статуса отзыва
export function updateReviewStatus(id: string, approved: boolean, moderated: boolean): boolean {
  try {
    const reviews = getReviews()
    const updatedReviews = reviews.map((review) => {
      if (review.id === id) {
        return {
          ...review,
          approved,
          moderated,
        }
      }
      return review
    })
    saveReviews(updatedReviews)
    return true
  } catch (error) {
    console.error("Ошибка при обновлении статуса отзыва:", error)
    return false
  }
}

// Функция для получения настроек доставки
export function getDeliveryPricing(): DeliveryPricing[] {
  try {
    const storedPricing = localStorage.getItem(STORAGE_KEYS.DELIVERY_PRICING)
    if (storedPricing) {
      const parsedPricing = JSON.parse(storedPricing)
      if (Array.isArray(parsedPricing) && parsedPricing.length > 0) {
        return parsedPricing
      }
    }

    // Если настройки не найдены, используем значения по умолчанию
    localStorage.setItem(STORAGE_KEYS.DELIVERY_PRICING, JSON.stringify(DEFAULT_DELIVERY_PRICING))
    return DEFAULT_DELIVERY_PRICING
  } catch (error) {
    console.error("Ошибка при получении настроек доставки:", error)
    return DEFAULT_DELIVERY_PRICING
  }
}

// Функция для сохранения настроек доставки
export function saveDeliveryPricing(pricing: DeliveryPricing[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.DELIVERY_PRICING, JSON.stringify(pricing))
  } catch (error) {
    console.error("Ошибка при сохранении настроек доставки:", error)
  }
}

// Функция для получения коэффициента доставки
export function getDeliveryCoefficient(): number {
  try {
    const storedCoefficient = localStorage.getItem(STORAGE_KEYS.DELIVERY_COEFFICIENT)
    if (storedCoefficient) {
      const parsedCoefficient = Number.parseFloat(storedCoefficient)
      if (!isNaN(parsedCoefficient)) {
        return parsedCoefficient
      }
    }

    // Если коэффициент не найден, используем значение по умолчанию
    localStorage.setItem(STORAGE_KEYS.DELIVERY_COEFFICIENT, DEFAULT_DELIVERY_COEFFICIENT.toString())
    return DEFAULT_DELIVERY_COEFFICIENT
  } catch (error) {
    console.error("Ошибка при получении коэффициента доставки:", error)
    return DEFAULT_DELIVERY_COEFFICIENT
  }
}

// Функция для сохранения коэффициента доставки
export function saveDeliveryCoefficient(coefficient: number): void {
  try {
    localStorage.setItem(STORAGE_KEYS.DELIVERY_COEFFICIENT, coefficient.toString())
  } catch (error) {
    console.error("Ошибка при сохранении коэффициента доставки:", error)
  }
}

// Функция для расчета стоимости доставки
export function calculateDeliveryCost(orderAmount: number): number {
  try {
    const pricing = getDeliveryPricing()
    const coefficient = getDeliveryCoefficient()

    // Находим подходящий диапазон цен
    const pricingRule = pricing.find(
      (rule) =>
        orderAmount >= rule.minOrderAmount && (rule.maxOrderAmount === null || orderAmount <= rule.maxOrderAmount),
    )

    // Если правило найдено, применяем его
    if (pricingRule) {
      return Math.round(pricingRule.price * coefficient)
    }

    // Если правило не найдено, используем стандартную стоимость
    return Math.round(350 * coefficient)
  } catch (error) {
    console.error("Ошибка при расчете стоимости доставки:", error)
    return 350
  }
}

// Функция для экспорта всех данных (для резервного копирования)
export function exportAllData(): {
  products: Product[]
  orders: Order[]
  reviews: Review[]
  deliveryPricing: DeliveryPricing[]
  deliveryCoefficient: number
} {
  return {
    products: getProducts(),
    orders: getOrders(),
    reviews: getReviews(),
    deliveryPricing: getDeliveryPricing(),
    deliveryCoefficient: getDeliveryCoefficient(),
  }
}

// Функция для импорта всех данных (для восстановления из резервной копии)
export function importAllData(data: {
  products?: Product[]
  orders?: Order[]
  reviews?: Review[]
  deliveryPricing?: DeliveryPricing[]
  deliveryCoefficient?: number
}): void {
  try {
    if (data.products) saveProducts(data.products)
    if (data.orders) saveOrders(data.orders)
    if (data.reviews) saveReviews(data.reviews)
    if (data.deliveryPricing) saveDeliveryPricing(data.deliveryPricing)
    if (data.deliveryCoefficient) saveDeliveryCoefficient(data.deliveryCoefficient)
  } catch (error) {
    console.error("Ошибка при импорте данных:", error)
  }
}

