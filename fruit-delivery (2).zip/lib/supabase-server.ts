// Обновляем настройки Supabase с предоставленными учетными данными
import { createClient } from "@supabase/supabase-js"
import type { Product, Order, Review } from "@/lib/types"
import { products as fallbackProducts } from "@/lib/products"

// Используем предоставленные учетные данные для Supabase
const supabaseUrl = "https://bammhzizejhmefodbfhj.supabase.co"
const supabaseKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJhbW1oeml6ZWpobWVmb2RiZmhqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIyNjY5NjYsImV4cCI6MjA1Nzg0Mjk2Nn0._r1EBO_90bWLW4fsZ1s6LD2-VMXFIx3JzAhs7v2wgD0"

// Флаг, указывающий, настроен ли Supabase
const isSupabaseConfigured = supabaseUrl !== "" && supabaseKey !== ""

// Создаем клиент Supabase
const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    })
  : null

// Функция для проверки доступности Supabase
export async function isSupabaseAvailable(): Promise<boolean> {
  if (!isSupabaseConfigured || !supabase) return false

  try {
    // Пробуем выполнить простой запрос для проверки соединения
    const { error } = await supabase.from("products").select("count", { count: "exact", head: true })
    return !error
  } catch (error) {
    console.error("Supabase connection check failed:", error)
    return false
  }
}

// Функция для получения продуктов из Supabase
export async function fetchProducts(): Promise<Product[]> {
  // Если Supabase не настроен, возвращаем локальные данные
  if (!isSupabaseConfigured || !supabase) {
    console.log("Supabase not configured, using fallback products")
    return fallbackProducts
  }

  try {
    const { data, error } = await supabase.from("products").select("*").order("name")

    if (error) {
      console.error("Error fetching products from Supabase:", error)
      return fallbackProducts
    }

    return data && data.length > 0 ? data : fallbackProducts
  } catch (error) {
    console.error("Failed to fetch products from Supabase:", error)
    return fallbackProducts
  }
}

// Остальные функции для работы с Supabase
export async function addProduct(product: Product): Promise<Product | null> {
  if (!isSupabaseConfigured || !supabase) return product

  try {
    const { data, error } = await supabase.from("products").insert([product]).select()
    if (error) throw error
    return data?.[0] || product
  } catch (error) {
    console.error("Failed to add product to Supabase:", error)
    return product
  }
}

export async function updateProduct(product: Product): Promise<Product | null> {
  if (!isSupabaseConfigured || !supabase) return product

  try {
    const { data, error } = await supabase.from("products").update(product).eq("id", product.id).select()
    if (error) throw error
    return data?.[0] || product
  } catch (error) {
    console.error("Failed to update product in Supabase:", error)
    return product
  }
}

export async function deleteProduct(id: string): Promise<boolean> {
  if (!isSupabaseConfigured || !supabase) return true

  try {
    const { error } = await supabase.from("products").delete().eq("id", id)
    if (error) throw error
    return true
  } catch (error) {
    console.error("Failed to delete product from Supabase:", error)
    return false
  }
}

export async function saveOrder(order: Order): Promise<Order | null> {
  if (!isSupabaseConfigured || !supabase) return order

  try {
    const { data, error } = await supabase.from("orders").insert([order]).select()
    if (error) throw error
    return data?.[0] || order
  } catch (error) {
    console.error("Failed to save order to Supabase:", error)
    return order
  }
}

export async function fetchOrders(): Promise<Order[]> {
  if (!isSupabaseConfigured || !supabase) return []

  try {
    const { data, error } = await supabase.from("orders").select("*").order("date", { ascending: false })
    if (error) throw error
    return data || []
  } catch (error) {
    console.error("Failed to fetch orders from Supabase:", error)
    return []
  }
}

export async function updateOrderStatus(id: string, status: string, statusHistory: any[]): Promise<boolean> {
  if (!isSupabaseConfigured || !supabase) return true

  try {
    const { error } = await supabase.from("orders").update({ status, statusHistory }).eq("id", id)
    if (error) throw error
    return true
  } catch (error) {
    console.error("Failed to update order status in Supabase:", error)
    return false
  }
}

// Modify the fetchReviews function to better handle the missing table error
export async function fetchReviews(): Promise<Review[]> {
  if (!isSupabaseConfigured || !supabase) return []

  try {
    // Try to fetch reviews
    const { data, error } = await supabase.from("reviews").select("*").order("date", { ascending: false })

    // If there's an error about the table not existing, return empty array without logging the error
    if (error && error.message && error.message.includes("does not exist")) {
      console.log("Reviews table does not exist in Supabase, using local storage")
      return []
    }

    // For other errors, throw to be caught by the catch block
    if (error) throw error

    return data || []
  } catch (error) {
    // Don't log the error if it's about the missing table
    if (error instanceof Error && !error.message.includes("does not exist")) {
      console.error("Failed to fetch reviews from Supabase:", error)
    }
    return []
  }
}

// Similarly update saveReview function
export async function saveReview(review: Review): Promise<Review | null> {
  if (!isSupabaseConfigured || !supabase) return review

  try {
    const { data, error } = await supabase.from("reviews").insert([review]).select()

    // If there's an error about the table not existing, return the review without logging the error
    if (error && error.message && error.message.includes("does not exist")) {
      console.log("Reviews table does not exist in Supabase, using local storage only")
      return review
    }

    // For other errors, throw to be caught by the catch block
    if (error) throw error

    return data?.[0] || review
  } catch (error) {
    // Don't log the error if it's about the missing table
    if (error instanceof Error && !error.message.includes("does not exist")) {
      console.error("Failed to save review to Supabase:", error)
    }
    return review
  }
}

// And update updateReviewStatus function
export async function updateReviewStatus(id: string, approved: boolean, moderated: boolean): Promise<boolean> {
  if (!isSupabaseConfigured || !supabase) return true

  try {
    const { error } = await supabase
      .from("reviews")
      .update({
        approved: approved,
        moderated: moderated,
      })
      .eq("id", id)

    // If there's an error about the table not existing, return true without logging the error
    if (error && error.message && error.message.includes("does not exist")) {
      console.log("Reviews table does not exist in Supabase, using local storage only")
      return true
    }

    // For other errors, throw to be caught by the catch block
    if (error) throw error

    return true
  } catch (error) {
    // Don't log the error if it's about the missing table
    if (error instanceof Error && !error.message.includes("does not exist")) {
      console.error("Failed to update review status in Supabase:", error)
    }
    return false
  }
}

