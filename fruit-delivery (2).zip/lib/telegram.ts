// Функция для отправки уведомления о новом заказе в Telegram
export async function sendOrderNotification(order: any) {
  try {
    // Используем предоставленные учетные данные
    const botToken = "8042908103:AAE_XguZVUqMjyLRyBpiYrercQPu9xQT9LY"
    const chatId = "6052414618" // ID вашего Telegram

    // Формируем текст сообщения
    const orderItems = order.items
      ? order.items
          .map((item: any) => `${item.name} - ${item.quantity} кг x ${item.price} ₽ = ${item.price * item.quantity} ₽`)
          .join("\n")
      : "Нет товаров"

    const message = `
🛒 *Новый заказ #${order.id ? order.id.split("-")[1] : "Неизвестно"}*
----------------------------------
*Товары:*
${orderItems}
----------------------------------
*Итого за товары:* ${order.totalPrice || 0} ₽
${order.discount > 0 ? `*Скидка:* ${order.discount} ₽` : ""}
*Доставка:* ${order.deliveryCost || 0} ₽
*К оплате:* ${order.finalPrice || 0} ₽
----------------------------------
*Информация о клиенте:*
${
  order.customerInfo
    ? `
Имя: ${order.customerInfo.name || "Не указано"}
Телефон: ${order.customerInfo.phone || "Не указано"}
Адрес: ${order.customerInfo.address || "Не указано"}
${order.customerInfo.floor ? `Этаж: ${order.customerInfo.floor}` : ""}
Тип доставки: ${order.customerInfo.deliveryType === "door" ? "До двери" : "До подъезда"}
Способ оплаты: ${order.customerInfo.paymentMethod === "cash" ? "Наличными при получении" : "Онлайн"}
${order.customerInfo.comment ? `Комментарий: ${order.customerInfo.comment}` : ""}
`
    : "Информация о клиенте отсутствует"
}
  `.trim()

    // Отправляем сообщение через Telegram API
    const telegramApiUrl = `https://api.telegram.org/bot${botToken}/sendMessage`

    const response = await fetch(telegramApiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "Markdown",
      }),
    })

    const data = await response.json()

    if (!data.ok) {
      console.error(`Telegram API error: ${data.description}`)
      return false
    }

    return true
  } catch (error) {
    console.error("Failed to send Telegram notification:", error)
    return false
  }
}

// Функция для отправки уведомления об изменении статуса заказа
export async function sendStatusUpdateNotification(order: any, newStatus: string) {
  try {
    // Используем предоставленные учетные данные
    const botToken = "8042908103:AAE_XguZVUqMjyLRyBpiYrercQPu9xQT9LY"
    const chatId = "6052414618" // ID вашего Telegram

    // Получаем текстовое описание статуса
    const statusText = getStatusText(newStatus)

    // Проверяем наличие необходимых данных
    const orderId = order.id ? order.id.split("-")[1] : "Неизвестно"
    const customerName = order.customerInfo?.name || "Неизвестно"
    const customerPhone = order.customerInfo?.phone || "Неизвестно"
    const orderTotal = order.finalPrice || 0

    const message = `
📦 *Обновление статуса заказа #${orderId}*
----------------------------------
Новый статус: *${statusText}*
Клиент: ${customerName}
Телефон: ${customerPhone}
Сумма заказа: ${orderTotal} ₽
  `.trim()

    // Отправляем сообщение через Telegram API
    const telegramApiUrl = `https://api.telegram.org/bot${botToken}/sendMessage`

    const response = await fetch(telegramApiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "Markdown",
      }),
    })

    const data = await response.json()

    if (!data.ok) {
      console.error(`Telegram API error: ${data.description}`)
      return false
    }

    return true
  } catch (error) {
    console.error("Failed to send Telegram notification:", error)
    return false
  }
}

// Функция для получения текстового описания статуса
function getStatusText(status: string): string {
  switch (status) {
    case "created":
      return "Заказ создан"
    case "processing":
      return "Заказ обрабатывается"
    case "packaging":
      return "Заказ собирается"
    case "finding_courier":
      return "Поиск курьера"
    case "in_delivery":
      return "В пути"
    case "delivered":
      return "Доставлен"
    case "cancelled":
      return "Отменен"
    default:
      return "Неизвестный статус"
  }
}

