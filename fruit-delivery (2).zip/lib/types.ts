export interface Product {
  id: string
  name: string
  description: string
  price: number
  category: "vegetables" | "fruits" | "dryFruits" | "drinks" | "other"
  image?: string
  images?: string[] // Поддержка нескольких изображений
  stock?: number // Количество товара в наличии
  inStock?: boolean // Доступность товара
}

export interface CartItem extends Product {
  quantity: number
}

export interface Order {
  id: string
  userId: string
  items: CartItem[]
  totalPrice: number
  discount: number
  finalPrice: number
  deliveryCost: number
  status: "created" | "processing" | "packaging" | "finding_courier" | "in_delivery" | "delivered" | "cancelled"
  statusHistory: {
    status: string
    timestamp: string
  }[]
  address: string
  phone: string
  name: string
  date: string
  paymentMethod: "cash" | "online"
  reviewed?: boolean
  customerInfo: {
    name: string
    phone: string
    address: string
    floor?: string
    deliveryType: "entrance" | "door"
    paymentMethod: "cash" | "online"
    comment?: string
  }
}

export interface BonusCard {
  userId: string
  discountPercent: number
  totalSpent: number
  lastOrderDate: string
  lastOrderAmount: number
}

export interface Review {
  id: string
  userId: string
  userName: string
  orderId: string
  productId?: string
  rating: number
  text: string
  images?: string[]
  date: string
  approved: boolean
  moderated: boolean
}

export interface BonusInfo {
  userId: string
  userName: string
  userPhone: string
  lastOrderAmount: number
  discountPercent: number
  lastOrderDate: string
  nextResetDate: string
}

// Новые типы для настроек доставки
export interface DeliveryPricing {
  minOrderAmount: number
  maxOrderAmount: number | null // null означает "без ограничения"
  price: number
}

