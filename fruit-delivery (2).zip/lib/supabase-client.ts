import type { Product, Order, Review } from "@/lib/types"
import { products as fallbackProducts } from "@/lib/products"

// Клиентский файл не использует напрямую переменные окружения Supabase

// Функция для проверки доступности Supabase
export async function isSupabaseAvailable(): Promise<boolean> {
  try {
    const response = await fetch("/api/supabase/check")
    const data = await response.json()
    return data.available
  } catch (error) {
    console.error("Failed to check Supabase availability:", error)
    return false
  }
}

// Функция для получения продуктов через API
export async function fetchProducts(): Promise<Product[]> {
  try {
    const response = await fetch("/api/products")
    const data = await response.json()
    return data.products || fallbackProducts
  } catch (error) {
    console.error("Failed to fetch products:", error)
    return fallbackProducts
  }
}

// Функция для добавления продукта через API
export async function addProduct(product: Product): Promise<Product | null> {
  try {
    const response = await fetch("/api/products", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(product),
    })
    const data = await response.json()
    return data.product || product
  } catch (error) {
    console.error("Failed to add product:", error)
    return product
  }
}

// Функция для обновления продукта через API
export async function updateProduct(product: Product): Promise<Product | null> {
  try {
    const response = await fetch(`/api/products/${product.id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(product),
    })
    const data = await response.json()
    return data.product || product
  } catch (error) {
    console.error("Failed to update product:", error)
    return product
  }
}

// Функция для удаления продукта через API
export async function deleteProduct(id: string): Promise<boolean> {
  try {
    const response = await fetch(`/api/products/${id}`, {
      method: "DELETE",
    })
    const data = await response.json()
    return data.success || false
  } catch (error) {
    console.error("Failed to delete product:", error)
    return false
  }
}

// Функция для сохранения заказа через API
export async function saveOrder(order: Order): Promise<Order | null> {
  try {
    const response = await fetch("/api/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(order),
    })
    const data = await response.json()
    return data.order || order
  } catch (error) {
    console.error("Failed to save order:", error)
    return order
  }
}

// Функция для получения заказов через API
export async function fetchOrders(): Promise<Order[]> {
  try {
    const response = await fetch("/api/orders")
    const data = await response.json()
    return data.orders || []
  } catch (error) {
    console.error("Failed to fetch orders:", error)
    return []
  }
}

// Функция для обновления статуса заказа через API
export async function updateOrderStatus(id: string, status: string, statusHistory: any[]): Promise<boolean> {
  try {
    const response = await fetch(`/api/orders/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ status, statusHistory }),
    })
    const data = await response.json()
    return data.success || false
  } catch (error) {
    console.error("Failed to update order status:", error)
    return false
  }
}

// Функция для сохранения отзыва через API
export async function saveReview(review: Review): Promise<Review | null> {
  try {
    const response = await fetch("/api/reviews", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(review),
    })
    const data = await response.json()
    return data.review || review
  } catch (error) {
    console.error("Failed to save review:", error)
    return review
  }
}

// Функция для получения отзывов через API
export async function fetchReviews(): Promise<Review[]> {
  try {
    const response = await fetch("/api/reviews")
    const data = await response.json()
    return data.reviews || []
  } catch (error) {
    console.error("Failed to fetch reviews:", error)
    return []
  }
}

// Исправляем функцию updateReviewStatus, чтобы она корректно отправляла параметры
export async function updateReviewStatus(id: string, approved: boolean, moderated: boolean): Promise<boolean> {
  try {
    const response = await fetch(`/api/reviews/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        approved: approved,
        moderated: moderated,
      }),
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return data.success || false
  } catch (error) {
    console.error("Failed to update review status:", error)
    return false
  }
}

